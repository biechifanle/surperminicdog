#!/usr/bin/env python3
"""MID80 SuperMimic -> native MuJoCo, with a Linux USB/Bluetooth gamepad.

Run from any directory (the repository's robot assets must remain in place):
  python scripts/sim2sim.py --checkpoint <velocity_terrain_model.pt>
  python scripts/sim2sim.py --checkpoint <model.pt> --terrain stairs_3
  python scripts/sim2sim.py --list-gamepad
  python scripts/sim2sim.py --checkpoint <model.pt> --headless --seconds 5 --command .5 0 0

No mjlab/Warp environment or CUDA is needed. Physics and inference run on CPU.
Default Xbox mapping: A enable, B zero command, X reset, LB/RB previous/next
terrain, Back exit. Left stick forward/left, right stick left turn. Reset or
disconnect disarms motion; press A again. Keyboard: Space stop, R reset,
N/P next/previous terrain, Q exit. Viewer mouse controls remain available.

This runs nominal robot parameters (no encoder/COM/friction randomization).
The policy's observation layout, gains, scales and 50 Hz control rate match
training. Native MuJoCo and Warp contact trajectories need not be identical.
"""

from __future__ import annotations

import argparse
from contextlib import contextmanager, nullcontext
import errno
import fcntl
import math
import os
from pathlib import Path
from queue import Empty, SimpleQueue
import struct
import sys
import threading
import time

import mujoco
import numpy as np
import torch
from torch import nn

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

# These helpers are simulator-independent. Do not import train.py or the mjlab
# environment: this entry point runs the second simulator directly.
from deep_robotics_model.mid80wheeldog.generate_terrain import (
    SPAWN_ORIGIN, TERRAIN_NAMES, TILE_SIZE,
)
from go2_supermimic.locomotion import COMMAND_SCALE
from go2_supermimic.robot.constants import (
    BASE_BODY_NAME, JOINT_NAMES, JOINT_VEL_OBS_SCALE, LEG_ACTION_SCALE,
    WHEEL_ACTION_SCALE,
)
from go2_supermimic.supermimic import state as st
from go2_supermimic.supermimic.driver import validate_checkpoint_task
from go2_supermimic.supermimic.world_model import RunningNorm, mlp
from go2_supermimic.target import terrain as tr
from go2_supermimic.target.box_heightfield import build_box_height_field

DEFAULT_SCENE = ROOT / "deep_robotics_model/mid80wheeldog/mjcf/scene_terrain.xml"
PHYSICS_DT = 0.005
DECIMATION = 4
CONTROL_DT = PHYSICS_DT * DECIMATION
HISTORY = 5
TERMS = st.VELOCITY_TERRAIN_OBS_TERMS
OBS_DIM = sum(dim for _, dim in TERMS) * HISTORY
EFFORT = np.array([80.0] * 12 + [90.0] * 4)


class Actor(nn.Module):
    """Deployment copy of the training actor, including saved RunningNorm."""

    def __init__(self, hidden):
        super().__init__()
        self.norm = RunningNorm(OBS_DIM)
        self.net = mlp(OBS_DIM, tuple(hidden), 16, act=nn.ELU)

    def forward(self, obs):
        return self.net(self.norm(obs))


def load_policy(path: str | Path) -> Actor:
    checkpoint = torch.load(Path(path).expanduser(), map_location="cpu", weights_only=False)
    st.validate_checkpoint_robot(checkpoint)
    validate_checkpoint_task(checkpoint, "velocity", TERMS, HISTORY)
    if checkpoint.get("obs_dim") != OBS_DIM:
        raise ValueError(f"Use a MID80-Velocity-Terrain checkpoint with {OBS_DIM} observations; "
                         "flat-ground and chase policies are incompatible with this script.")
    actor = Actor(checkpoint["cfg"]["actor_hidden"])
    actor.load_state_dict(checkpoint["actor"], strict=True)
    actor.eval()
    actor.requires_grad_(False)
    return actor


def pd_torques(action, q, qd):
    """Leg-position PD + wheel-velocity PD, in policy joint order."""
    tau = np.empty(16, dtype=np.float64)
    tau[:12] = 40.0 * (LEG_ACTION_SCALE * action[:12] - q[:12]) - 2.0 * qd[:12]
    tau[12:] = 0.6 * (WHEEL_ACTION_SCALE * action[12:] - qd[12:])
    return np.clip(tau, -EFFORT, EFFORT)


class NativeSim:
    """One native MuJoCo robot on all thirteen authored terrain tiles."""

    def __init__(self, terrain="flat", seed=0, delay_steps=-1, scene=DEFAULT_SCENE):
        if terrain not in TERRAIN_NAMES:
            raise ValueError(f"Unknown terrain {terrain!r}")
        if delay_steps not in (-1, 0, 1, 2):
            raise ValueError("delay_steps must be -1 (random 0–2), 0, 1 or 2")
        self.rng = np.random.default_rng(seed)
        self.delay_steps = delay_steps
        self.terrain = terrain
        spec = mujoco.MjSpec.from_file(str(Path(scene).expanduser().resolve()))
        # The robot XML has no actuators. Native torque motors reproduce the
        # explicit PD used by mjlab, including per-physics-step saturation.
        for name, limit in zip(JOINT_NAMES, EFFORT):
            spec.add_actuator(
                name=f"sim2sim_{name}", target=name, trntype=mujoco.mjtTrn.mjTRN_JOINT,
                gear=[1, 0, 0, 0, 0, 0], gainprm=[1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                ctrllimited=True, ctrlrange=[-limit, limit],
                forcelimited=True, forcerange=[-limit, limit],
            )
        self.model = model = spec.compile()
        ids = np.array([model.joint(name).id for name in JOINT_NAMES])
        self.qids = model.jnt_qposadr[ids].copy()
        self.vids = model.jnt_dofadr[ids].copy()
        self.motor_ids = np.array([model.actuator(f"sim2sim_{name}").id for name in JOINT_NAMES])
        self.base_id = model.body(BASE_BODY_NAME).id
        self.root_qadr = model.jnt_qposadr[model.joint("floating_base_joint").id]
        self.gyro_adr = model.sensor("imu_ang_vel").adr[0]
        model.dof_armature[self.vids] = [0.01] * 12 + [0.00243216] * 4
        model.dof_frictionloss[self.vids] = 0.0
        for gid in range(model.ngeom):
            name = model.geom(gid).name
            if name.endswith("_collision"):
                wheel = name.endswith("_wheel_collision")
                model.geom_contype[gid], model.geom_conaffinity[gid] = 2, 1
                model.geom_solref[gid] = (0.01, 1.0)
                model.geom_condim[gid] = 6 if wheel else 1
                model.geom_priority[gid] = 1 if wheel else 0
                if wheel:
                    model.geom_friction[gid] = (1.0, 0.005, 0.0005)
        opt = model.opt
        opt.timestep = PHYSICS_DT
        opt.integrator = mujoco.mjtIntegrator.mjINT_IMPLICITFAST
        opt.solver = mujoco.mjtSolver.mjSOL_NEWTON
        opt.cone = mujoco.mjtCone.mjCONE_ELLIPTIC
        opt.impratio, opt.iterations, opt.ls_iterations = 10, 10, 20
        opt.tolerance, opt.ls_tolerance, opt.ccd_iterations = 1e-8, 0.01, 50
        opt.gravity[:] = (0.0, 0.0, -9.81)
        self.data = mujoco.MjData(model)
        mujoco.mj_forward(model, self.data)
        terrain_ids = {model.body(name).id for name in TERRAIN_NAMES}
        self.origins = {
            name: self.data.xpos[model.body(name).id].copy() + np.asarray(SPAWN_ORIGIN)
            for name in TERRAIN_NAMES
        }
        centers = np.array(list(self.origins.values()))
        self.bounds = (float(centers[:, 0].min() - TILE_SIZE[0] / 2),
                       float(centers[:, 1].min() - TILE_SIZE[1] / 2),
                       float(centers[:, 0].max() + TILE_SIZE[0] / 2),
                       float(centers[:, 1].max() + TILE_SIZE[1] / 2))
        geom_ids = [i for i in range(model.ngeom) if model.geom_bodyid[i] in terrain_ids]
        self.field = build_box_height_field(model, self.data, geom_ids, self.bounds, 0.05, "cpu")
        self.last_action = np.zeros(16)
        self.delay_history: list[np.ndarray] = []
        self.history = torch.zeros(1, OBS_DIM)
        self.reset()

    def reset(self, terrain=None):
        if terrain is not None:
            if terrain not in self.origins:
                raise ValueError(f"Unknown terrain {terrain!r}")
            self.terrain = terrain
        mujoco.mj_resetData(self.model, self.data)
        self.data.qpos[self.root_qadr:self.root_qadr + 3] = self.origins[self.terrain] + (0, 0, 0.42)
        self.data.qpos[self.root_qadr + 3:self.root_qadr + 7] = (1, 0, 0, 0)
        self.data.qpos[self.qids] = 0.0
        self.last_action.fill(0)
        self.delay_history.clear()
        mujoco.mj_forward(self.model, self.data)
        frame = self.observe(np.zeros(3))
        # mjlab fills the entire history with the first frame on reset.
        self.history = torch.cat([frame[name].repeat(1, HISTORY) for name, _ in TERMS], -1)

    def observe(self, command):
        d = self.data
        rotation = d.xmat[self.base_id].reshape(3, 3)
        yaw = math.atan2(rotation[1, 0], rotation[0, 0])
        pos = torch.tensor(d.xpos[self.base_id], dtype=torch.float32).unsqueeze(0)
        rel = tr.relief(pos[:, :2], torch.tensor([yaw]), self.field)
        scan = pos[:, 2:3] - tr.ground(pos[:, :2], self.field)[:, None] + rel
        tensor = lambda value: torch.tensor(np.asarray(value).copy(), dtype=torch.float32).reshape(1, -1)
        return {
            "base_ang_vel": tensor(d.sensordata[self.gyro_adr:self.gyro_adr + 3]),
            "projected_gravity": tensor(rotation.T @ np.array([0.0, 0.0, -1.0])),
            "joint_pos": tensor(d.qpos[self.qids[:12]]),
            "joint_vel": tensor(d.qvel[self.vids] * JOINT_VEL_OBS_SCALE),
            "actions": tensor(self.last_action),
            "velocity_command": tensor(np.asarray(command) * COMMAND_SCALE),
            "height_scan": scan,
        }

    def step(self, action):
        action = np.asarray(action, dtype=np.float64)
        if action.shape != (16,) or not np.isfinite(action).all():
            raise ValueError("Policy must produce 16 finite actions")
        for _ in range(DECIMATION):
            self.delay_history.append(action.copy())
            self.delay_history = self.delay_history[-3:]
            lag = self.rng.integers(0, 3) if self.delay_steps == -1 else self.delay_steps
            delayed = self.delay_history[-1 - min(int(lag), len(self.delay_history) - 1)]
            self.data.ctrl[self.motor_ids] = pd_torques(
                delayed, self.data.qpos[self.qids], self.data.qvel[self.vids],
            )
            mujoco.mj_step(self.model, self.data)
        self.last_action[:] = action
        mujoco.mj_forward(self.model, self.data)
        if not np.isfinite(self.data.qpos).all() or not np.isfinite(self.data.qvel).all():
            raise RuntimeError("Native MuJoCo produced a nonfinite state")

    @torch.inference_mode()
    def policy_step(self, actor, command):
        frame = self.observe(command)
        self.history = st.push_history(self.history, frame, HISTORY, TERMS)
        if not torch.isfinite(self.history).all():
            raise RuntimeError("Nonfinite policy observation")
        action = actor(self.history)[0].cpu().numpy()
        self.step(action)
        return action

    def reset_reason(self):
        rotation = self.data.xmat[self.base_id].reshape(3, 3)
        if rotation[2, 2] < math.cos(math.radians(70)):
            return "fell over"
        x, y = self.data.xpos[self.base_id, :2]
        x0, y0, x1, y1 = self.bounds
        if not (x0 <= x <= x1 and y0 <= y <= y1):
            return "left the terrain map"
        return None


class Gamepad:
    """Read Linux ``/dev/input/js*`` events without blocking simulation.

    ``axes`` selects the joystick axes for vx, vy, and yaw; ``signs`` sets
    their directions. ``buttons`` maps action names to joystick button IDs.
    Axis values in ``poll()['axes']`` are dead-zone corrected and rescaled to
    [-1, 1]. Diagnostic ``raw_axes`` values are normalized but unfiltered.
    Temporary disconnects are safe and automatically retried once per second.
    """

    EVENT = struct.Struct("=IhBB")
    DEFAULT_BUTTONS = {
        "enable": 0,
        "stop": 1,
        "reset": 2,
        "prev": 4,
        "next": 5,
        "quit": 6,
    }

    def __init__(
        self,
        device: str = "/dev/input/js0",
        axes: tuple[int, int, int] = (1, 0, 3),
        signs: tuple[float, float, float] = (-1.0, -1.0, -1.0),
        deadzone: float = 0.12,
        buttons: dict[str, int] | None = None,
    ):
        if len(axes) != 3 or any(axis < 0 for axis in axes):
            raise ValueError("Gamepad axes must contain three non-negative IDs")
        if len(signs) != 3 or any(sign not in (-1.0, 1.0) for sign in signs):
            raise ValueError("Gamepad signs must contain three values of -1 or +1")
        if not 0.0 <= deadzone < 1.0:
            raise ValueError("Gamepad deadzone must be in [0, 1)")
        self.device = device
        self.axes = tuple(axes)
        self.signs = np.asarray(signs, dtype=np.float64)
        self.deadzone = float(deadzone)
        self.buttons = dict(self.DEFAULT_BUTTONS if buttons is None else buttons)
        if any(not isinstance(index, int) or index < 0 for index in self.buttons.values()):
            raise ValueError("Gamepad button IDs must be non-negative integers")
        self.fd: int | None = None
        self.name = ""
        self.axis_count: int | None = None
        self.button_count: int | None = None
        self.error = ""
        self._next_connect = 0.0
        self._closed = False
        self._buffer = bytearray()
        self._raw_axes: dict[int, float] = {}
        self._raw_buttons: dict[int, bool] = {}

    @property
    def connected(self) -> bool:
        return self.fd is not None

    def _clear_state(self):
        self._buffer.clear()
        self._raw_axes.clear()
        self._raw_buttons.clear()

    def _disconnect(self, error: str = ""):
        if self.fd is not None:
            try:
                os.close(self.fd)
            except OSError:
                pass
        self.fd = None
        self.error = error
        self._next_connect = time.monotonic() + 1.0
        self._clear_state()

    def _connect(self):
        if self._closed or time.monotonic() < self._next_connect:
            return
        self._next_connect = time.monotonic() + 1.0
        self._clear_state()
        try:
            self.fd = os.open(
                self.device, os.O_RDONLY | os.O_NONBLOCK | getattr(os, "O_CLOEXEC", 0)
            )
        except OSError as exc:
            self.error = str(exc)
            return
        self.error = ""
        self.name = ""
        self.axis_count = self.button_count = None
        # Optional metadata; a joystick can still be used if ioctl fails.
        try:
            name = bytearray(256)
            fcntl.ioctl(self.fd, 0x80006A13 | (len(name) << 16), name, True)
            self.name = name.split(b"\0", 1)[0].decode("utf-8", errors="replace")
        except OSError:
            pass
        for attribute, request in (("axis_count", 0x80016A11), ("button_count", 0x80016A12)):
            try:
                count = bytearray(1)
                fcntl.ioctl(self.fd, request, count, True)
                setattr(self, attribute, count[0])
            except OSError:
                pass

    def poll(self) -> dict:
        """Return a fresh snapshot, plus button rising edges since the last poll."""
        pressed: set[str] = set()
        if self.fd is None:
            self._connect()
        if self.fd is not None:
            # Bound each poll so an unusually busy event source cannot freeze
            # simulation. Normal joystick queues are exhausted in one read.
            for _ in range(32):
                try:
                    chunk = os.read(self.fd, 4096)
                except OSError as exc:
                    if exc.errno in (errno.EAGAIN, errno.EWOULDBLOCK):
                        break
                    if exc.errno == errno.EINTR:
                        continue
                    self._disconnect(str(exc))
                    pressed.clear()
                    break
                if not chunk:
                    self._disconnect("Joystick disconnected")
                    pressed.clear()
                    break
                self._buffer.extend(chunk)
                complete_bytes = (len(self._buffer) // self.EVENT.size) * self.EVENT.size
                for offset in range(0, complete_bytes, self.EVENT.size):
                    _, value, event_type, number = self.EVENT.unpack_from(self._buffer, offset)
                    initial = bool(event_type & 0x80)
                    event_type &= ~0x80
                    if event_type == 0x02:
                        self._raw_axes[number] = value / (32768.0 if value < 0 else 32767.0)
                    elif event_type == 0x01:
                        previous = self._raw_buttons.get(number, False)
                        down = bool(value)
                        self._raw_buttons[number] = down
                        if down and not previous and not initial:
                            pressed.update(name for name, index in self.buttons.items() if index == number)
                del self._buffer[:complete_bytes]
        raw = np.array([self._raw_axes.get(index, 0.0) for index in self.axes])
        axes = np.sign(raw) * np.maximum(np.abs(raw) - self.deadzone, 0.0) / (1.0 - self.deadzone)
        axes = np.clip(axes * self.signs, -1.0, 1.0)
        return {
            "connected": self.connected,
            "axes": axes,
            "pressed": pressed,
            "raw_axes": dict(self._raw_axes),
            "raw_buttons": dict(self._raw_buttons),
        }

    def close(self):
        self._closed = True
        self._disconnect()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()


class ControlState:
    """Convert stick input to bounded, smoothed velocity commands."""

    def __init__(self, max_speeds=(1.0, 0.5, 0.3, 1.0), tau=0.15):
        self.max_speeds = np.asarray(max_speeds, dtype=float)
        self.tau = float(tau)
        if self.max_speeds.shape != (4,) or not np.isfinite(self.max_speeds).all() or (self.max_speeds < 0).any():
            raise ValueError("Four non-negative speed limits are required")
        if not math.isfinite(self.tau) or self.tau < 0:
            raise ValueError("Command smoothing time must be non-negative")
        self.armed = False
        self.command = np.zeros(3)

    def stop(self):
        self.armed = False
        self.command.fill(0)

    def update(self, snapshot, dt=CONTROL_DT):
        events = set(snapshot["pressed"])
        # Stop/reset always wins when several buttons arrive in the same poll.
        if not snapshot["connected"] or events & {"stop", "reset", "prev", "next", "quit"}:
            self.stop()
        elif "enable" in events:
            self.armed = True
        if self.armed:
            axes = np.clip(np.asarray(snapshot["axes"]), -1, 1)
            forward, backward, lateral, yaw = self.max_speeds
            target = axes * (forward if axes[0] >= 0 else backward, lateral, yaw)
            alpha = 1.0 if self.tau == 0 else 1.0 - math.exp(-dt / self.tau)
            self.command += alpha * (target - self.command)
        return self.command.copy(), events


@contextmanager
def native_viewer(model, data, key_callback):
    import mujoco.viewer

    previous_threads = set(threading.enumerate())
    viewer = mujoco.viewer.launch_passive(model, data, key_callback=key_callback)
    # launch_passive starts a daemon render thread. Handle.close() only signals
    # it: wait for this launch's threads to finish before Python/GLFW teardown,
    # otherwise short runs can segfault at interpreter exit on Linux.
    viewer_threads = [thread for thread in threading.enumerate() if thread not in previous_threads]
    try:
        yield viewer
    finally:
        viewer.close()
        for thread in viewer_threads:
            thread.join()


def build_parser():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--checkpoint", type=Path, help="MID80-Velocity-Terrain SuperMimic .pt")
    parser.add_argument("--terrain", choices=TERRAIN_NAMES, default="flat", help="Starting tile; all tiles remain available")
    parser.add_argument("--scene", type=Path, default=DEFAULT_SCENE)
    parser.add_argument("--joystick", default="/dev/input/js0")
    parser.add_argument("--axes", type=int, nargs=3, default=(1, 0, 3), metavar=("VX", "VY", "YAW"))
    parser.add_argument("--axis-signs", type=float, nargs=3, default=(-1, -1, -1))
    parser.add_argument("--deadzone", type=float, default=0.12)
    parser.add_argument("--smoothing", type=float, default=0.15, help="Command filter time constant [s]")
    for name, default in Gamepad.DEFAULT_BUTTONS.items():
        parser.add_argument(f"--{name}-button", type=int, default=default)
    parser.add_argument("--list-gamepad", action="store_true", help="Print live raw axes/buttons; no checkpoint needed")
    parser.add_argument("--max-forward", type=float, default=1.0)
    parser.add_argument("--max-backward", type=float, default=0.5)
    parser.add_argument("--max-lateral", type=float, default=0.3)
    parser.add_argument("--max-yaw", type=float, default=1.0)
    parser.add_argument("--delay-steps", type=int, choices=(-1, 0, 1, 2), default=-1,
                        help="Actuator target delay in physics steps; -1 samples 0–2 as in training")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--threads", type=int, default=1, help="Torch CPU threads for one robot")
    parser.add_argument("--seconds", type=float, default=0, help="Duration in simulation seconds; 0 runs until quit")
    parser.add_argument("--headless", action="store_true", help="No viewer, run as fast as possible")
    parser.add_argument("--command", type=float, nargs=3, metavar=("VX", "VY", "YAW"),
                        help="Fixed test command instead of the gamepad")
    parser.add_argument("--no-auto-reset", action="store_true")
    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()
    if args.threads < 1 or not math.isfinite(args.seconds) or args.seconds < 0:
        parser.error("--threads must be positive and --seconds must be non-negative")
    if args.headless and (args.command is None or args.seconds <= 0):
        parser.error("--headless requires --command VX VY YAW and a positive --seconds")
    if not args.list_gamepad and args.checkpoint is None:
        parser.error("--checkpoint is required (except with --list-gamepad)")
    if args.command is not None and not np.isfinite(args.command).all():
        parser.error("--command values must be finite")
    torch.set_num_threads(args.threads)
    gamepad = Gamepad(args.joystick, tuple(args.axes), tuple(args.axis_signs), args.deadzone,
                      {name: getattr(args, f"{name}_button") for name in Gamepad.DEFAULT_BUTTONS})
    controls = ControlState((args.max_forward, args.max_backward, args.max_lateral, args.max_yaw), args.smoothing)
    try:
        if args.list_gamepad:
            print("Move sticks and press buttons to identify IDs. Ctrl+C exits.")
            start = time.monotonic()
            while args.seconds == 0 or time.monotonic() - start < args.seconds:
                snap = gamepad.poll()
                print(f"{gamepad.name or args.joystick}: connected={snap['connected']} "
                      f"axes={snap['raw_axes']} buttons={snap['raw_buttons']} {gamepad.error}", flush=True)
                time.sleep(0.2)
            return
        actor = load_policy(args.checkpoint)
        sim = NativeSim(args.terrain, args.seed, args.delay_steps, args.scene)
        keys = SimpleQueue()
        if args.headless:
            viewer_context = nullcontext(None)
        else:
            viewer_context = native_viewer(sim.model, sim.data, keys.put)
        print(f"Native MuJoCo | terrain={sim.terrain} | obs={OBS_DIM} | actions=16 | policy=50 Hz | CPU")
        print("A: enable | B/Space: zero velocity | X/R: reset | LB/P, RB/N: terrain | Back/Q: exit")
        print("Stick defaults: axes 1/0/3, signs -1/-1/-1. Use --list-gamepad to check your controller.")
        steps = resets = 0
        last_connected = None
        deadline = time.monotonic()
        last_report = deadline
        fixed_command = None if args.command is None else np.asarray(args.command, dtype=float)
        with viewer_context as viewer:
            if viewer is not None:
                with viewer.lock():
                    viewer.cam.type = mujoco.mjtCamera.mjCAMERA_FREE
                    viewer.cam.distance, viewer.cam.azimuth, viewer.cam.elevation = 3.2, 135, -20
                    viewer.opt.geomgroup[3] = 0  # Collision meshes are not the visual model.
            while (viewer is None or viewer.is_running()) and (args.seconds == 0 or steps * CONTROL_DT < args.seconds):
                events = set()
                while True:
                    try:
                        key = keys.get_nowait()
                    except Empty:
                        break
                    action = {32: "stop", 82: "reset", 78: "next", 80: "prev", 81: "quit"}.get(key)
                    if action:
                        events.add(action)
                if fixed_command is None:
                    snapshot = gamepad.poll()
                    snapshot["pressed"].update(events)
                    if snapshot["connected"] != last_connected:
                        controls.stop()
                        print(f"Gamepad connected: {gamepad.name or args.joystick}; press A to enable"
                              if snapshot["connected"] else f"Waiting for {args.joystick}: {gamepad.error}", flush=True)
                        last_connected = snapshot["connected"]
                    command, events = controls.update(snapshot)
                else:
                    command = fixed_command.copy()
                    if "stop" in events:
                        fixed_command.fill(0)
                        command.fill(0)
                if "quit" in events:
                    break
                if events & {"reset", "prev", "next"}:
                    index = TERRAIN_NAMES.index(sim.terrain)
                    index = (index + int("next" in events) - int("prev" in events)) % len(TERRAIN_NAMES)
                    sim.reset(TERRAIN_NAMES[index])
                    controls.stop()
                    command.fill(0)
                    print(f"Reset: {sim.terrain}. Press A to enable movement.", flush=True)
                    resets += 1
                sim.policy_step(actor, command)
                steps += 1
                reason = sim.reset_reason()
                if reason and not args.no_auto_reset:
                    sim.reset()
                    controls.stop()
                    resets += 1
                    print(f"Reset ({reason}): {sim.terrain}", flush=True)
                if viewer is not None:
                    with viewer.lock():
                        viewer.cam.lookat[:] = sim.data.xpos[sim.base_id]
                    if hasattr(viewer, "set_texts"):
                        mode = "FIXED COMMAND" if fixed_command is not None else (
                            "ENABLED" if controls.armed else "ZERO COMMAND - press A")
                        viewer.set_texts((None, None,
                            f"MID80 | {sim.terrain} | {mode}\n"
                            f"vx {command[0]:+.2f}   vy {command[1]:+.2f} m/s   yaw {command[2]:+.2f} rad/s\n"
                            "A enable | B/Space zero | X/R reset | LB/P prev | RB/N next | Back/Q quit",
                            None))
                    viewer.sync()
                    deadline += CONTROL_DT
                    delay = deadline - time.monotonic()
                    if delay > 0:
                        time.sleep(delay)
                    elif delay < -0.2:
                        deadline = time.monotonic()
                now = time.monotonic()
                if now - last_report >= 2.0:
                    print(f"t={steps * CONTROL_DT:.1f}s terrain={sim.terrain} "
                          f"{'enabled' if controls.armed or fixed_command is not None else 'zero command'} "
                          f"vx={command[0]:+.2f} vy={command[1]:+.2f} yaw={command[2]:+.2f}", flush=True)
                    last_report = now
        print(f"Finished: {steps} control steps, {steps * CONTROL_DT:.2f}s simulated, {resets} resets")
    except KeyboardInterrupt:
        print("Stopped.")
    finally:
        gamepad.close()


if __name__ == "__main__":
    main()
