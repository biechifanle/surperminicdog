"""Velocity commands with a scan of the same XML collision terrain used by physics."""

from dataclasses import dataclass

import mujoco

from mjlab.tasks.velocity.mdp.velocity_command import (
  UniformVelocityCommand, UniformVelocityCommandCfg,
)

from go2_supermimic.env.xml_terrain import TILE_SIZE
from go2_supermimic.target import terrain as tr
from go2_supermimic.target.box_heightfield import build_box_height_field


class TerrainVelocityCommand(UniformVelocityCommand):
  def __init__(self, cfg, env):
    super().__init__(cfg, env)
    origins = env.scene.terrain.terrain_origins.reshape(-1, 3).cpu().numpy()
    bounds = (origins[:, 0].min() - TILE_SIZE[0] / 2,
              origins[:, 1].min() - TILE_SIZE[1] / 2,
              origins[:, 0].max() + TILE_SIZE[0] / 2,
              origins[:, 1].max() + TILE_SIZE[1] / 2)
    model = env.sim.mj_model
    terrain_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "terrain")
    if terrain_id < 0:
      raise ValueError("MID80 terrain body is missing")
    geoms = [g for g in range(model.ngeom) if model.geom_bodyid[g] == terrain_id]
    if not geoms:
      raise ValueError("MID80 terrain has no collision geometry")
    data = mujoco.MjData(model)
    mujoco.mj_forward(model, data)
    self.height_field = build_box_height_field(
      model, data, geoms, bounds, cfg.field_res, env.device,
    )

  def ground_under_base(self):
    return tr.ground(self.robot.data.root_link_pos_w[:, :2], self.height_field)

  def scan(self):
    data = self.robot.data
    rel = tr.relief(data.root_link_pos_w[:, :2], data.heading_w, self.height_field)
    return data.root_link_pos_w[:, 2:3] - self.ground_under_base()[:, None] + rel


@dataclass(kw_only=True)
class TerrainVelocityCommandCfg(UniformVelocityCommandCfg):
  field_res: float = 0.05

  def build(self, env):
    return TerrainVelocityCommand(self, env)
