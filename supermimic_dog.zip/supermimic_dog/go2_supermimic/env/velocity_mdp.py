"""Simulator wrappers for the shared basic-locomotion reward equations."""

from __future__ import annotations

from typing import TYPE_CHECKING

import torch

from go2_supermimic.locomotion import velocity_tracking_terms
from go2_supermimic.target.interface import yaw_rotate_inverse

if TYPE_CHECKING:
  from mjlab.envs.manager_based_rl_env import ManagerBasedRlEnv


def _tracking_terms(
  env: ManagerBasedRlEnv, command_name: str,
) -> dict[str, torch.Tensor]:
  data = env.scene["robot"].data
  return velocity_tracking_terms(
    yaw_rotate_inverse(data.root_link_lin_vel_w, data.heading_w),
    data.root_link_ang_vel_b,
    env.command_manager.get_command(command_name),
  )


def track_lin_vel_xy(
  env: ManagerBasedRlEnv, command_name: str,
) -> torch.Tensor:
  return _tracking_terms(env, command_name)["track_lin_vel_xy"]


def track_ang_vel_z(
  env: ManagerBasedRlEnv, command_name: str,
) -> torch.Tensor:
  return _tracking_terms(env, command_name)["track_ang_vel_z"]


def lin_vel_z_l2(
  env: ManagerBasedRlEnv, command_name: str,
) -> torch.Tensor:
  return _tracking_terms(env, command_name)["lin_vel_z_l2"]


def height_scan(env: ManagerBasedRlEnv, command_name: str) -> torch.Tensor:
  return env.command_manager.get_term(command_name).scan()


def base_height_low(env: ManagerBasedRlEnv, command_name: str,
                    min_height: float) -> torch.Tensor:
  term = env.command_manager.get_term(command_name)
  height = term.robot.data.root_link_pos_w[:, 2] - term.ground_under_base()
  return (min_height - height).clamp(min=0.0)


def outside_terrain_tile(env: ManagerBasedRlEnv,
                         half_size: tuple[float, float]) -> torch.Tensor:
  """End a tile traversal as a timeout before reaching an unsupported edge."""
  xy = env.scene["robot"].data.root_link_pos_w[:, :2] - env.scene.env_origins[:, :2]
  return (xy.abs() > xy.new_tensor(half_size)).any(dim=-1)
