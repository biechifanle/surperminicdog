"""Independent flat and XML-terrain basic movement tasks."""

from __future__ import annotations

from mjlab.envs import ManagerBasedRlEnvCfg
from mjlab.envs import mdp as envs_mdp
from mjlab.managers import TerminationTermCfg
from mjlab.managers.event_manager import EventTermCfg
from mjlab.managers.observation_manager import ObservationTermCfg
from mjlab.managers.reward_manager import RewardTermCfg
from mjlab.tasks.velocity import mdp as vel_mdp
from mjlab.tasks.velocity.mdp import UniformVelocityCommandCfg
from mjlab.terrains import TerrainEntityCfg
from mjlab.utils.noise import UniformNoiseCfg

from go2_supermimic.env import velocity_mdp
from go2_supermimic.env.env_cfg import mid80_chase_env_cfg
from go2_supermimic.locomotion import COMMAND_SCALE, MIN_BASE_HEIGHT

CMD = "velocity"


def mid80_velocity_env_cfg(play: bool = False) -> ManagerBasedRlEnvCfg:
  """Reuse the MID80 physics/control boundary with a separate movement task."""
  cfg = mid80_chase_env_cfg(play=play)
  cfg.commands = {
    CMD: UniformVelocityCommandCfg(
      entity_name="robot", resampling_time_range=(4.0, 8.0),
      rel_standing_envs=0.1, heading_command=False, debug_vis=True,
      ranges=UniformVelocityCommandCfg.Ranges(
        lin_vel_x=(-0.5, 1.0), lin_vel_y=(-0.3, 0.3), ang_vel_z=(-1.0, 1.0),
      ),
    ),
  }
  # Keep the five proprioception terms and five-frame history. The final three
  # values in each frame now encode commanded vx, vy and yaw rate (53 x 5 = 265).
  actor_terms = cfg.observations["actor"].terms
  del actor_terms["target"]
  actor_terms["velocity_command"] = ObservationTermCfg(
    func=vel_mdp.generated_commands, params={"command_name": CMD}, scale=COMMAND_SCALE,
  )

  # Preserve the already matched simulator/imagination posture and actuator
  # costs, excluding every chase, dodge and target-specific reward.
  shared_rewards = {
    name: cfg.rewards[name]
    for name in (
      "upright", "tilt_rate_l2", "joint_deviation_l2", "base_height_low",
      "action_rate_l2", "dof_pos_limits", "joint_torques_l2", "joint_acc_l2",
      "terminated",
    )
  }
  shared_rewards["base_height_low"].params["min_height"] = MIN_BASE_HEIGHT
  cfg.rewards = {
    "track_lin_vel_xy": RewardTermCfg(
      func=velocity_mdp.track_lin_vel_xy, weight=3.0, params={"command_name": CMD},
    ),
    "track_ang_vel_z": RewardTermCfg(
      func=velocity_mdp.track_ang_vel_z, weight=1.5, params={"command_name": CMD},
    ),
    "lin_vel_z_l2": RewardTermCfg(
      func=velocity_mdp.lin_vel_z_l2, weight=-1.0, params={"command_name": CMD},
    ),
    **shared_rewards,
  }
  cfg.curriculum = {}
  return cfg


def mid80_velocity_terrain_env_cfg(play: bool = False) -> ManagerBasedRlEnvCfg:
  """Thirteen fixed XML terrain types, with a flat spawn area in each tile."""
  from go2_supermimic.env.terrains import clean_look
  from go2_supermimic.env.velocity_command import TerrainVelocityCommandCfg
  from go2_supermimic.env.xml_terrain import TILE_SIZE, mid80_terrain_generator_cfg

  cfg = mid80_velocity_env_cfg(play=play)
  cfg.scene.terrain = TerrainEntityCfg(
    terrain_type="generator", terrain_generator=mid80_terrain_generator_cfg(),
    max_init_terrain_level=0,
  )
  clean_look(cfg.scene.terrain)
  cfg.commands[CMD] = TerrainVelocityCommandCfg(
    entity_name="robot", resampling_time_range=(4.0, 8.0),
    rel_standing_envs=0.1, heading_command=False, debug_vis=True,
    ranges=UniformVelocityCommandCfg.Ranges(
      lin_vel_x=(-0.5, 1.0), lin_vel_y=(-0.3, 0.3), ang_vel_z=(-1.0, 1.0),
    ),
  )
  cfg.observations["actor"].terms["height_scan"] = ObservationTermCfg(
    func=velocity_mdp.height_scan, params={"command_name": CMD},
    noise=UniformNoiseCfg(n_min=-0.02, n_max=0.02),
  )
  cfg.rewards["base_height_low"].func = velocity_mdp.base_height_low
  cfg.rewards["base_height_low"].params = {
    "command_name": CMD, "min_height": MIN_BASE_HEIGHT,
  }
  # Event order matters: choose the tile before placing the robot there.
  cfg.events = {
    "randomize_terrain": EventTermCfg(func=envs_mdp.randomize_terrain, mode="reset"),
    **cfg.events,
  }
  cfg.events["reset_base"].params["pose_range"].update({
    "x": (-0.2, 0.2), "y": (-0.2, 0.2), "yaw": (-0.25, 0.25),
  })
  cfg.terminations["terrain_boundary"] = TerminationTermCfg(
    func=velocity_mdp.outside_terrain_tile, time_out=True,
    params={"half_size": (TILE_SIZE[0] / 2 - 0.65, TILE_SIZE[1] / 2 - 0.65)},
  )
  return cfg
