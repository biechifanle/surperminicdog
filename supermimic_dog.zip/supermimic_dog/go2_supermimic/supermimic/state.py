"""Bridge between the mjlab env and the SuperMimic learner.

Defines the world-model state, the sim context xi, the robot planar pose, and
an exact re-implementation of the actor observation so that a policy trained
in imagination can be evaluated (and deployed) in the real env unchanged.

World-model state s (74):
  base height (1), gravity in body frame (3), base linear velocity in the yaw
  frame (3), base angular velocity in body frame (3), leg pos - default (12),
  leg and wheel velocity (16), then hip, knee and wheel positions relative to the base in the
  yaw frame (3 x 4 x 3, legs ordered FR FL RR RL). The limb points make contact
  changes (touchdown / liftoff) explicit and let imagination compute per-leg
  collisions with obstacles exactly as the env does.
The planar pose (x, y, yaw) is not part of s: the model predicts its change in
the previous yaw frame, which keeps the dynamics translation/yaw invariant.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

import torch

from go2_supermimic.robot.constants import (
  BASE_BODY_NAME,
  FOOT_GEOM_NAMES,
  FOOT_SITE_NAMES,
  HIP_BODY_NAMES,
  JOINT_NAMES,
  JOINT_VEL_OBS_SCALE,
  KNEE_BODY_NAMES,
  LEG_JOINT_NAMES,
  WHEEL_JOINT_NAMES,
  WHEEL_RADIUS,
)
from go2_supermimic.target import interface as ti
from go2_supermimic.target.interface import yaw_rotate_inverse
from go2_supermimic.target.terrain import SCAN_POINTS, ground

STATE_DIM = 74
POSE_DELTA_DIM = 3
CONTEXT_DIM = 4  # foot friction (1), base COM offset (3)
NUM_LEG_JOINTS = len(LEG_JOINT_NAMES)
NUM_JOINTS = len(JOINT_NAMES)

# Slices into s.
Z = slice(0, 1)
GRAV = slice(1, 4)
V_YAW = slice(4, 7)
W_B = slice(7, 10)
Q = slice(10, 22)
QD = slice(22, 38)
HIPS = slice(38, 50)
KNEES = slice(50, 62)
FEET = slice(62, 74)
LEGS = ("FR", "FL", "RR", "RL")
FOOT_SITES = FOOT_SITE_NAMES
HIP_BODIES = HIP_BODY_NAMES
KNEE_BODIES = KNEE_BODY_NAMES
FOOT_RADIUS = WHEEL_RADIUS


def checkpoint_robot_metadata() -> dict:
  """Identify the robot and tensor layout to prevent loading a Go2 policy."""
  return {"name": "mid80", "joint_names": list(JOINT_NAMES), "state_dim": STATE_DIM,
          "observation_version": 1}


def validate_checkpoint_robot(checkpoint: dict) -> None:
  if checkpoint.get("robot") != checkpoint_robot_metadata():
    raise ValueError(
      "This checkpoint is not compatible with MID80: expected 12 leg-position and "
      "4 wheel-velocity actions with MID80 observation scaling. Go2 checkpoints "
      "cannot be resumed or used as expert policies; train a new MID80 checkpoint."
    )


def policy_joint_ids(robot) -> list[int]:
  """Map policy order (12 legs, then 4 wheels) to the simulator joint order."""
  names = list(robot.joint_names)
  return [names.index(name) for name in JOINT_NAMES]


def leg_encoder_bias(robot) -> torch.Tensor:
  return robot.data.encoder_bias[:, policy_joint_ids(robot)[:NUM_LEG_JOINTS]]


def feet_world_z(s: torch.Tensor) -> torch.Tensor:
  """World-frame foot site heights (N, 4) from the state (yaw rotation keeps z)."""
  return s[:, Z] + s[:, FEET].reshape(-1, 4, 3)[..., 2]


def limb_points_world(s: torch.Tensor, pose: torch.Tensor) -> dict[str, torch.Tensor]:
  """World-frame hips, knees and feet (each (N, 4, 3)) from the state and the
  planar pose (x, y, yaw)."""
  c, si = pose[:, 2].cos(), pose[:, 2].sin()
  base = torch.cat([pose[:, :2], s[:, Z]], -1).unsqueeze(1)
  out = {}
  for name, sl in (("hips", HIPS), ("knees", KNEES), ("feet", FEET)):
    rel = s[:, sl].reshape(-1, 4, 3)
    x = c.unsqueeze(-1) * rel[..., 0] - si.unsqueeze(-1) * rel[..., 1]
    y = si.unsqueeze(-1) * rel[..., 0] + c.unsqueeze(-1) * rel[..., 1]
    out[name] = base + torch.stack([x, y, rel[..., 2]], -1)
  return out

# Actor observation terms in env order, with per-frame dims (see env_cfg.py);
# ("lidar", rays) follows with obstacles, ("height_scan", SCAN_POINTS) on terrain.
OBS_TERMS = (
  ("base_ang_vel", 3),
  ("projected_gravity", 3),
  ("joint_pos", NUM_LEG_JOINTS),
  ("joint_vel", NUM_JOINTS),
  ("actions", NUM_JOINTS),
  ("target", ti.DIM),
)
VELOCITY_OBS_TERMS = OBS_TERMS[:-1] + (("velocity_command", 3),)
VELOCITY_TERRAIN_OBS_TERMS = VELOCITY_OBS_TERMS + (("height_scan", SCAN_POINTS),)
# Uniform observation noise half-widths, matching env_cfg.py.
OBS_NOISE = {
  "base_ang_vel": 0.2,
  "projected_gravity": 0.05,
  "joint_pos": 0.01,
  "joint_vel": 1.5,
  "lidar": 0.03,
  "height_scan": 0.02,
}


def obs_terms(env_cfg) -> tuple[tuple[str, int], ...]:
  """Actor terms (name, per-frame dim) of an env config, in order."""
  names = list(env_cfg.observations["actor"].terms)
  if "velocity" in env_cfg.commands:
    terms = VELOCITY_TERRAIN_OBS_TERMS if "height_scan" in names else VELOCITY_OBS_TERMS
    expected = [name for name, _ in terms]
    if names != expected:
      raise ValueError(f"velocity actor terms must be {expected}, got {names}")
    return terms
  rays = env_cfg.commands["target"].target.obstacles.lidar_rays
  known = dict(OBS_TERMS) | {"lidar": rays, "height_scan": SCAN_POINTS}
  terms = tuple((n, known[n]) for n in names)
  assert [n for n, _ in terms[: len(OBS_TERMS)]] == [n for n, _ in OBS_TERMS], names
  return terms


@dataclass
class RobotConsts:
  """Constants in policy joint order, with wheel angles excluded from positions."""

  default_q: torch.Tensor  # (N, 12)
  action_scale: torch.Tensor  # (N, 16)
  kp: torch.Tensor  # (16,), zero for wheels
  kd: torch.Tensor  # (16,), wheel velocity gains in the last four entries
  effort: torch.Tensor  # (16,)
  soft_limits: torch.Tensor  # (N, 12, 2)


def robot_consts(env) -> RobotConsts:
  robot = env.scene["robot"]
  terms = (env.action_manager.get_term("joint_pos"), env.action_manager.get_term("joint_vel"))
  for term, names in zip(terms, (LEG_JOINT_NAMES, WHEEL_JOINT_NAMES)):
    if tuple(term._target_names) != tuple(names):
      raise ValueError(f"MID80 action order must be {names}, got {term._target_names}")
  jids = policy_joint_ids(robot)
  leg_ids = jids[:NUM_LEG_JOINTS]
  kp, kd, eff = [], [], []
  for n in JOINT_NAMES:
    for act in robot.cfg.articulation.actuators:
      if any(re.fullmatch(expr, n) for expr in act.target_names_expr):
        kp.append(act.stiffness)
        kd.append(act.damping)
        eff.append(act.effort_limit)
        break
    else:
      raise KeyError(f"no actuator for joint {n}")
  dev = env.device
  scales = [torch.as_tensor(term._scale, device=dev).expand(env.num_envs, len(names))
            for term, names in zip(terms, (LEG_JOINT_NAMES, WHEEL_JOINT_NAMES))]
  return RobotConsts(
    default_q=robot.data.default_joint_pos[:, leg_ids].clone(),
    action_scale=torch.cat(scales, dim=-1).clone(),
    kp=torch.tensor(kp, device=dev),
    kd=torch.tensor(kd, device=dev),
    effort=torch.tensor(eff, device=dev),
    soft_limits=robot.data.soft_joint_pos_limits[:, leg_ids].clone(),
  )


_LIMB_IDS: dict[int, tuple[list[int], list[int], list[int]]] = {}


def limb_positions_w(robot) -> dict[str, torch.Tensor]:
  """World-frame hip, knee and foot positions of an mjlab robot entity, each
  (N, 4, 3), legs ordered FR FL RR RL."""
  key = id(robot)
  if key not in _LIMB_IDS:
    hips, _ = robot.find_bodies(HIP_BODIES, preserve_order=True)
    knees, _ = robot.find_bodies(KNEE_BODIES, preserve_order=True)
    feet, _ = robot.find_sites(FOOT_SITES, preserve_order=True)
    _LIMB_IDS[key] = (hips, knees, feet)
  hips, knees, feet = _LIMB_IDS[key]
  d = robot.data
  return {"hips": d.body_link_pos_w[:, hips], "knees": d.body_link_pos_w[:, knees],
          "feet": d.site_pos_w[:, feet]}


def robot_state(env, field=None) -> torch.Tensor:
  """World-model state of the robot. On terrain (a HeightField) the base height
  is measured above the ground under the base."""
  robot = env.scene["robot"]
  d = robot.data
  joint_ids = policy_joint_ids(robot)
  leg_ids = joint_ids[:NUM_LEG_JOINTS]
  heading = d.heading_w
  v_yaw = yaw_rotate_inverse(d.root_link_lin_vel_w, heading)
  limbs = limb_positions_w(env.scene["robot"])
  rel = []
  for name in ("hips", "knees", "feet"):
    r = limbs[name] - d.root_link_pos_w.unsqueeze(1)
    rel.append(torch.stack([yaw_rotate_inverse(r[:, i], heading) for i in range(4)], 1))
  base_h = d.root_link_pos_w[:, 2:3] - ground(d.root_link_pos_w[:, :2], field).unsqueeze(-1)
  return torch.cat(
    [
      base_h,
      d.projected_gravity_b,
      v_yaw,
      d.root_link_ang_vel_b,
      d.joint_pos[:, leg_ids] - d.default_joint_pos[:, leg_ids],
      d.joint_vel[:, joint_ids],
    ] + [r.reshape(-1, 12) for r in rel],
    dim=-1,
  )


def planar_pose(env) -> torch.Tensor:
  d = env.scene["robot"].data
  return torch.cat([d.root_link_pos_w[:, :2], d.heading_w.unsqueeze(-1)], dim=-1)


def pose_delta(pose0: torch.Tensor, pose1: torch.Tensor) -> torch.Tensor:
  """Planar motion from pose0 to pose1, expressed in pose0's yaw frame."""
  c, s = pose0[:, 2].cos(), pose0[:, 2].sin()
  dx, dy = pose1[:, 0] - pose0[:, 0], pose1[:, 1] - pose0[:, 1]
  dyaw = torch.atan2((pose1[:, 2] - pose0[:, 2]).sin(), (pose1[:, 2] - pose0[:, 2]).cos())
  return torch.stack([c * dx + s * dy, -s * dx + c * dy, dyaw], dim=-1)


def apply_pose_delta(pose: torch.Tensor, delta: torch.Tensor) -> torch.Tensor:
  c, s = pose[:, 2].cos(), pose[:, 2].sin()
  x = pose[:, 0] + c * delta[:, 0] - s * delta[:, 1]
  y = pose[:, 1] + s * delta[:, 0] + c * delta[:, 1]
  return torch.stack([x, y, pose[:, 2] + delta[:, 2]], dim=-1)


class ContextReader:
  """Reads the per-env domain-randomization context xi from the sim model."""

  def __init__(self, env):
    robot = env.scene["robot"]
    local_geoms, _ = robot.find_geoms(FOOT_GEOM_NAMES)
    local_body, _ = robot.find_bodies(BASE_BODY_NAME)
    self.foot_geom = robot.indexing.geom_ids[local_geoms[0]]
    self.base_body = robot.indexing.body_ids[local_body[0]]
    self.env = env
    self.base_ipos0 = self._ipos().clone()

  def _ipos(self) -> torch.Tensor:
    ipos = self.env.sim.model.body_ipos
    return ipos[:, self.base_body] if ipos.ndim == 3 else ipos[self.base_body].expand(
      self.env.num_envs, 3
    )

  def read(self) -> torch.Tensor:
    fr = self.env.sim.model.geom_friction
    mu = fr[:, self.foot_geom, 0] if fr.ndim == 3 else fr[self.foot_geom, 0].expand(
      self.env.num_envs
    )
    return torch.cat([mu.unsqueeze(-1), self._ipos() - self.base_ipos0], dim=-1)


def obs_frame(
  s: torch.Tensor,
  last_action: torch.Tensor,
  target_obs: torch.Tensor | None,
  encoder_bias: torch.Tensor,
  noise: bool,
  lidar: torch.Tensor | None = None,
  height_scan: torch.Tensor | None = None,
  velocity_command: torch.Tensor | None = None,
) -> dict[str, torch.Tensor]:
  """One frame of each actor observation term, computed from the model state."""
  frame = {
    "base_ang_vel": s[:, W_B],
    "projected_gravity": s[:, GRAV],
    "joint_pos": s[:, Q] + encoder_bias,
    "joint_vel": s[:, QD],
    "actions": last_action,
  }
  if target_obs is not None:
    frame["target"] = target_obs
  if velocity_command is not None:
    from go2_supermimic.locomotion import COMMAND_SCALE

    frame["velocity_command"] = velocity_command * velocity_command.new_tensor(COMMAND_SCALE)
  if lidar is not None:
    frame["lidar"] = lidar
  if height_scan is not None:
    frame["height_scan"] = height_scan
  if noise:
    for k, w in OBS_NOISE.items():
      if k in frame:
        frame[k] = frame[k] + (torch.rand_like(frame[k]) * 2 - 1) * w
  # mjlab adds sensor noise before applying the configured observation scale.
  frame["joint_vel"] = frame["joint_vel"] * JOINT_VEL_OBS_SCALE
  return frame


def push_history(hist: torch.Tensor, frame: dict[str, torch.Tensor], h: int,
                 terms: tuple[tuple[str, int], ...] = OBS_TERMS) -> torch.Tensor:
  """Shift each term's flattened history (oldest->newest) and append the new frame."""
  out, i = [], 0
  for name, dim in terms:
    block = hist[:, i : i + dim * h]
    out.append(torch.cat([block[:, dim:], frame[name]], dim=-1))
    i += dim * h
  return torch.cat(out, dim=-1)
