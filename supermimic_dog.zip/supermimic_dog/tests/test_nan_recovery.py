"""Nonfinite physics must end only the affected episode and preserve replay."""

import math

import pytest
import torch

from go2_supermimic.supermimic import state as st


@pytest.mark.parametrize("task", [
  "MID80-Velocity-Flat", "MID80-Velocity-Terrain", "MID80-Chase-Flat",
  "MID80-Chase-Obstacles", "MID80-Chase-Terrain",
])
def test_mid80_tasks_enable_physics_nan_termination(task):
  import go2_supermimic.env  # noqa: F401
  from mjlab.envs import mdp
  from mjlab.tasks.registry import load_env_cfg

  term = load_env_cfg(task).terminations["nan_state"]
  assert term.func is mdp.nan_detection
  assert not term.time_out


@pytest.fixture(scope="module")
def gpu_trainer(tmp_path_factory):
  # Defer CUDA detection and environment construction until fixture setup; test
  # collection and the task-configuration checks also work on CPU-only hosts.
  if not torch.cuda.is_available():
    pytest.skip("real CUDA device required for MuJoCo Warp recovery checks")
  from go2_supermimic.supermimic.train import TrainCfg, Trainer

  cfg = TrainCfg(
    task="MID80-Velocity-Terrain", device="cuda:0", num_envs=8,
    buffer_len=32, archive_size=32, wm_window=2, wm_batch=8, wm_updates=1,
    wm_hidden=(32, 32), actor_hidden=(32, 32), critic_hidden=(32, 32),
    horizon=4, imag_batch=8, critic_epochs=1, critic_minibatches=2,
    compile=False, collect_steps=1, explore_frac=0.0, action_noise=0.0,
    explore_noise=0.0, iterations=1, warmup_iterations=0,
    log_root=str(tmp_path_factory.mktemp("nan_recovery")), run_name="test",
  )
  trainer = Trainer(cfg)
  try:
    yield trainer
  finally:
    trainer.writer.close()
    trainer.env.close()


@pytest.fixture
def trainer(gpu_trainer):
  trainer = gpu_trainer
  with torch.no_grad():
    obs, _ = trainer.env.reset()
    trainer.obs = obs["actor"]
    trainer.a_prev.zero_()
    trainer.ou.zero_()
    trainer.buf.ptr = trainer.buf.size = 0
    trainer.ep_stats.clear()
    # A stationary policy keeps ordinary falls from obscuring the local reset
    # assertions. The recovery test subsequently exercises learning too.
    for parameter in trainer.actor.net.parameters():
      parameter.zero_()
  return trainer


def _assert_finite(trainer):
  for name in ("qpos", "qvel", "qacc", "qacc_warmstart", "sensordata"):
    assert torch.isfinite(getattr(trainer.env.sim.data, name)).all(), name
  assert torch.isfinite(trainer.obs).all()
  assert torch.isfinite(st.robot_state(trainer.env, field=trainer.field)).all()
  for name in ("s", "pose", "a", "a_prev", "obs", "gen", "done", "relief"):
    assert torch.isfinite(getattr(trainer.buf, name)[:, :trainer.buf.size]).all(), name
  for name in ("actor", "wm", "critic"):
    for key, value in getattr(trainer, name).state_dict().items():
      assert torch.isfinite(value).all(), f"{name}.{key}"


def _inject_and_check(trainer, monkeypatch, mode, value, env_id):
  env, sim = trainer.env, trainer.env.sim
  old_lengths = env.episode_length_buf.clone()
  old_count = trainer.wm.in_norm.count.clone()
  slot = trainer.buf.ptr
  original_step, original_forward = sim.step, sim.forward
  original_env_step = env.step
  calls = 0
  injected = False

  def corrupt():
    nonlocal injected
    # qpos[0] is base x. Refresh derived quantities so this also reaches the
    # terrain sampling path which previously cast NaN to an invalid integer.
    sim.data.qpos[env_id, 0] = value
    original_forward()
    injected = True

  def bad_final_substep():
    nonlocal calls
    original_step()
    calls += 1
    if calls == env.cfg.decimation:
      corrupt()

  def bad_final_forward():
    original_forward()
    if not injected:
      corrupt()

  def overflowing_observation(action):
    nonlocal injected
    obs, reward, terminated, truncated, extras = original_env_step(action)
    obs["actor"][env_id, 0] = value
    assert torch.isfinite(obs["actor"][env_id]).all()
    assert not torch.isfinite(obs["actor"][env_id].to(trainer.buf.obs.dtype)).all()
    injected = True
    return obs, reward, terminated, truncated, extras

  with monkeypatch.context() as patch:
    if mode == "physics":
      patch.setattr(sim, "step", bad_final_substep)
    elif mode == "late_forward":
      patch.setattr(sim, "forward", bad_final_forward)
    else:
      assert mode == "observation_overflow"
      patch.setattr(env, "step", overflowing_observation)
    trainer.collect()
    torch.cuda.synchronize()

  assert injected
  expected_done = torch.zeros(env.num_envs, dtype=torch.bool, device=env.device)
  expected_done[env_id] = True
  assert torch.equal(trainer.buf.done[:, slot].bool(), expected_done)
  expected_lengths = old_lengths + 1
  expected_lengths[env_id] = 0
  assert torch.equal(env.episode_length_buf, expected_lengths)
  # Exclude the invalid successor from the world-model normalization statistics.
  assert float(trainer.wm.in_norm.count - old_count) == pytest.approx(env.num_envs - 1)
  assert (trainer.a_prev[env_id] == 0).all()
  assert (trainer.ou[env_id] == 0).all()
  _assert_finite(trainer)
  trainer.collect()
  torch.cuda.synchronize()
  _assert_finite(trainer)


def test_cuda_nonfinite_physics_recovers_locally_and_learning_continues(trainer, monkeypatch):
  for _ in range(3):
    trainer.collect()
  _assert_finite(trainer)
  # Reuse one environment compilation for both the termination manager and the
  # late-observation fallback, including nonfinite values other than NaN.
  for mode, value, env_id in (
    ("physics", float("nan"), 1),
    ("physics", float("inf"), 3),
    ("late_forward", float("nan"), 5),
    ("observation_overflow", 70_000.0, 7),
  ):
    _inject_and_check(trainer, monkeypatch, mode, value, env_id)
  trainer.it = 1
  assert math.isfinite(trainer.fit_world_model())
  metrics = trainer.improve_policy()
  torch.cuda.synchronize()
  assert all(math.isfinite(value) for value in metrics.values()), metrics
  _assert_finite(trainer)


@pytest.mark.parametrize("invalid_action", [float("nan"), float("inf")])
def test_nonfinite_action_stops_before_physics_or_replay(trainer, monkeypatch, invalid_action):
  trainer.collect()
  before_slot, before_size = trainer.buf.ptr, trainer.buf.size
  before_qpos = trainer.env.sim.data.qpos.clone()
  before_actor_count = trainer.actor.norm.count.clone()
  before_wm_count = trainer.wm.in_norm.count.clone()
  original_actor = trainer.actor.forward

  def bad_actor(obs):
    action = original_actor(obs)
    action[2, 0] = invalid_action
    return action

  def unexpected_step():
    pytest.fail("nonfinite action reached physics")

  monkeypatch.setattr(trainer.actor, "forward", bad_actor)
  monkeypatch.setattr(trainer.env.sim, "step", unexpected_step)
  with pytest.raises(RuntimeError, match="Non-finite collection input/action.*stopped before physics/replay"):
    trainer.collect()
  assert (trainer.buf.ptr, trainer.buf.size) == (before_slot, before_size)
  assert torch.equal(trainer.env.sim.data.qpos, before_qpos)
  assert torch.equal(trainer.actor.norm.count, before_actor_count)
  assert torch.equal(trainer.wm.in_norm.count, before_wm_count)
  _assert_finite(trainer)
