"""Check physical terrain geometry and the velocity learner's terrain inputs."""

import math

import mujoco
import numpy as np
import pytest
import torch

from go2_supermimic.supermimic import state as st
from go2_supermimic.target import terrain as tr


@pytest.fixture(scope="module")
def terrain_model():
  from mjlab.terrains.terrain_generator import TerrainGenerator
  from go2_supermimic.env.xml_terrain import mid80_terrain_generator_cfg

  cfg = mid80_terrain_generator_cfg()
  spec = mujoco.MjSpec()
  generator = TerrainGenerator(cfg, device="cpu")
  generator.compile(spec)
  model = spec.compile()
  data = mujoco.MjData(model)
  mujoco.mj_forward(model, data)
  return model, data, generator


def _ray_heights(model, data, xy):
  heights = []
  geom_id = np.zeros(1, dtype=np.int32)
  for x, y in np.asarray(xy).reshape(-1, 2):
    distance = mujoco.mj_ray(model, data, np.array([x, y, 5.0]),
                             np.array([0.0, 0.0, -1.0]), None, 1, -1, geom_id)
    assert distance >= 0, f"missing ground at ({x}, {y})"
    heights.append(5.0 - distance)
  return np.asarray(heights)


def test_every_requested_terrain_exists_and_spawn_footprint_is_clear(terrain_model):
  from go2_supermimic.env.xml_terrain import TERRAIN_NAMES, TILE_SIZE

  expected = ("flat", "rough", *(f"stairs_{i}" for i in range(1, 6)),
              "slope", *(f"platform_{i}" for i in range(1, 6)))
  model, data, generator = terrain_model
  assert tuple(TERRAIN_NAMES) == expected
  assert tuple(generator.cfg.sub_terrains) == expected
  assert tuple(TILE_SIZE) == (8.0, 6.0)
  assert generator.terrain_origins.shape == (1, 13, 3)
  assert (model.geom_contype & 1).all() and (model.geom_conaffinity & 2).all()
  # A MID80 body plus its reset jitter fits entirely on each starting pad.
  offsets = np.array([(x, y) for x in (-0.65, 0.0, 0.65) for y in (-0.5, 0.0, 0.5)])
  for origin in generator.terrain_origins[0]:
    heights = _ray_heights(model, data, origin[:2] + offsets)
    np.testing.assert_allclose(heights, origin[2], atol=1e-6)


def test_native_rays_measure_five_stair_sizes_platform_heights_and_slope(terrain_model):
  model, data, generator = terrain_model
  names = tuple(generator.cfg.sub_terrains)
  xs = np.arange(-3.9, 3.9001, 0.002)

  def profile(name):
    y = generator.terrain_origins[0, names.index(name), 1]
    return _ray_heights(model, data, np.column_stack([xs, np.full_like(xs, y)]))

  np.testing.assert_allclose(profile("flat"), 0.0, atol=1e-6)
  rough = profile("rough")
  assert np.ptp(rough) > 0.02 and len(np.unique(np.round(rough, 5))) >= 6
  for index, (rise, tread) in enumerate(zip((.04, .06, .08, .10, .12),
                                           (.50, .45, .40, .35, .30)), start=1):
    heights = np.round(profile(f"stairs_{index}"), 6)
    levels = np.unique(heights)
    assert len(levels) >= 4, "a staircase must contain several risers"
    np.testing.assert_allclose(np.diff(levels), rise, atol=1e-5)
    # Interior plateaus expose tread depth; the floor and top landing may be longer.
    transitions = np.flatnonzero(np.diff(heights)) + 1
    starts, ends = np.r_[0, transitions], np.r_[transitions, len(xs)]
    interior = (heights[starts] > 0) & (heights[starts] < heights.max())
    widths = (ends - starts)[interior] * 0.002
    assert len(widths) >= 2
    np.testing.assert_allclose(widths, tread, atol=0.003)
  for index, height in enumerate((.08, .12, .16, .20, .24), start=1):
    np.testing.assert_allclose(np.unique(np.round(profile(f"platform_{index}"), 6)),
                               [0.0, height], atol=1e-6)
  slopes = np.diff(profile("slope")) / 0.002
  sloping = np.abs(slopes[(np.abs(slopes) > .01) & (np.abs(slopes) < .5)])
  assert len(sloping) > 200
  np.testing.assert_allclose(sloping, math.tan(math.radians(10)), atol=1e-5)


def test_standalone_xml_scene_uses_the_same_terrain_geometry_as_training(terrain_model):
  from deep_robotics_model.mid80wheeldog.generate_terrain import SCENE_PATH

  training_model, training_data, generator = terrain_model
  scene_model = mujoco.MjModel.from_xml_path(str(SCENE_PATH))
  scene_data = mujoco.MjData(scene_model)
  mujoco.mj_forward(scene_model, scene_data)
  assert (scene_model.nq, scene_model.nv) == (23, 22)
  # Avoid the robot in the centre of the preview scene while sampling every
  # terrain type; body-local XML positions must become identical world surfaces.
  points = np.array([(x, origin[1] + .317)
                     for origin in generator.terrain_origins[0] for x in (-2.123, 2.123)])
  np.testing.assert_allclose(_ray_heights(scene_model, scene_data, points),
                             _ray_heights(training_model, training_data, points), atol=1e-6)


def test_training_height_map_matches_mujoco_on_all_thirteen_tiles(terrain_model):
  from go2_supermimic.target.box_heightfield import build_box_height_field

  model, data, generator = terrain_model
  field = build_box_height_field(model, data, list(range(model.ngeom)),
                                  (-3.975, -38.975, 3.975, 38.975), .05, "cpu")
  rng = np.random.default_rng(27)
  points = []
  for origin in generator.terrain_origins[0]:
    # Query exactly on map grid points; interpolation across a vertical edge is
    # intentionally smoothed and would not be an exact native-ray comparison.
    xy = rng.integers((-75, -55), (76, 56), size=(32, 2)) * .05 + .025
    xy[:, 1] += origin[1]
    points.append(xy)
  xy = np.concatenate(points)
  physical = _ray_heights(model, data, xy)
  sampled = field.sample(torch.tensor(xy, dtype=torch.float32)).numpy()
  np.testing.assert_allclose(sampled, physical, atol=3e-5)
  assert np.ptp(sampled) > .2, "height-map queries must cover elevated terrain"


def test_velocity_terrain_task_appends_scan_and_keeps_existing_tasks():
  import go2_supermimic.env  # noqa: F401
  from mjlab.tasks.registry import load_env_cfg
  from go2_supermimic.supermimic.train import TrainCfg

  terrain = load_env_cfg("MID80-Velocity-Terrain")
  flat = load_env_cfg("MID80-Velocity-Flat")
  chase = load_env_cfg("MID80-Chase-Flat")
  assert set(terrain.commands) == {"velocity"}
  assert st.obs_terms(terrain) == st.VELOCITY_OBS_TERMS + (("height_scan", 77),)
  assert sum(dim for _, dim in st.obs_terms(terrain)) * 5 == 650
  assert sum(dim for _, dim in st.obs_terms(flat)) * 5 == 265
  assert sum(dim for _, dim in st.obs_terms(chase)) * 5 == 390
  assert terrain.observations["actor"].history_length == 5
  assert tuple(terrain.actions) == tuple(flat.actions) == ("joint_pos", "joint_vel")
  assert set(terrain.rewards) == set(flat.rewards)
  assert terrain.scene.terrain.terrain_type == "generator"
  assert len(terrain.scene.terrain.terrain_generator.sub_terrains) == 13
  assert flat.scene.terrain.terrain_type == chase.scene.terrain.terrain_type == "plane"
  assert TrainCfg().task == "MID80-Chase-Flat"
  # Loading a terrain task must not append sensors to the flat task's dictionaries.
  terrain.observations["actor"].terms.clear()
  assert st.obs_terms(load_env_cfg("MID80-Velocity-Flat")) == st.VELOCITY_OBS_TERMS


def test_terrain_imagination_uses_ground_relative_scan_for_model_actor_and_critic(monkeypatch):
  from go2_supermimic.supermimic.imagine import ImagineCfg
  from go2_supermimic.supermimic.velocity_imagine import VelocityImagination, VelocityRewardWeights

  consts = st.RobotConsts(
    default_q=torch.zeros(1, 12),
    action_scale=torch.tensor([[.25] * 12 + [5.0] * 4]),
    kp=torch.tensor([40.0] * 12 + [0.0] * 4),
    kd=torch.tensor([2.0] * 12 + [.6] * 4),
    effort=torch.tensor([80.0] * 12 + [90.0] * 4),
    soft_limits=torch.tensor([-1.0, 1.0]).expand(1, 12, 2),
  )
  xs = torch.arange(-2.0, 2.001, .05)
  field = tr.HeightField((.1 * xs.square()).expand(81, -1).clone(), (-2., -2.), .05)
  terms = st.VELOCITY_OBS_TERMS + (("height_scan", tr.SCAN_POINTS),)
  imagine = VelocityImagination(ImagineCfg(weights=VelocityRewardWeights()), consts,
                                history=5, device="cpu", terms=terms, field=field)
  s = torch.zeros(1, st.STATE_DIM)
  s[:, st.Z] = .42
  s[:, st.GRAV] = torch.tensor([0., 0., -1.])
  pose = torch.tensor([[.23, .1, .3]], requires_grad=True)
  command = torch.tensor([[.5, .1, .2]])
  context = {"velocity_command": command}
  k = {"default_q": consts.default_q, "action_scale": consts.action_scale,
       "soft_limits": consts.soft_limits}
  captured = {}

  def world_model(state, action, previous, xi, relief):
    captured["relief"] = relief
    return state.clone(), torch.tensor([[.15, 0., .1]])

  # Remove only height-scan noise to test the actual _step observation wiring.
  monkeypatch.setitem(st.OBS_NOISE, "height_scan", 0.0)
  result = imagine._step(s, pose, torch.zeros(1, 16), torch.zeros(1, 650), context,
                         torch.zeros(1, st.CONTEXT_DIM), torch.zeros(1, 12), k,
                         torch.tensor([.02]), lambda hist: torch.zeros(1, 16), world_model)
  s_next, pose_next, _, history, _, reward, _, critic_input = result
  expected_relief = tr.relief(pose[:, :2], pose[:, 2], field)
  torch.testing.assert_close(captured["relief"], expected_relief)
  assert captured["relief"].abs().max() > .01
  scan_next = s_next[:, st.Z] + tr.relief(pose_next[:, :2], pose_next[:, 2], field)
  torch.testing.assert_close(history[:, -77:], scan_next)
  assert critic_input.shape == (1, 158)
  torch.testing.assert_close(critic_input[:, 77:154], s[:, st.Z] + expected_relief)
  assert torch.isfinite(reward).all()
  imagine.scan(s, pose, context, grad=True).sum().backward()
  assert torch.isfinite(pose.grad).all() and pose.grad.abs().sum() > 0


def test_flat_velocity_checkpoint_warm_start_preserves_actions_on_terrain():
  from go2_supermimic.supermimic.driver import validate_checkpoint_task
  from go2_supermimic.supermimic.train import Actor, expand_actor_new_terms

  torch.manual_seed(83)
  old_terms = st.VELOCITY_OBS_TERMS
  new_terms = old_terms + (("height_scan", tr.SCAN_POINTS),)
  checkpoint = {"cfg": {"task": "MID80-Velocity-Flat"}, "obs_terms": old_terms, "history": 5}
  validate_checkpoint_task(checkpoint, "velocity", new_terms, 5, allow_prefix=True)
  with pytest.raises(ValueError, match="task type"):
    validate_checkpoint_task(checkpoint, "chase", new_terms, 5, allow_prefix=True)
  old = Actor(265, (32, 32), 16)
  old.norm.mean.normal_()
  old.norm.var.uniform_(.5, 2.)
  new = Actor(650, (32, 32), 16)
  expand_actor_new_terms(old.state_dict(), new, old_terms, new_terms, 5)
  obs = torch.randn(8, 265)
  scans = torch.randn(8, 385)
  with torch.no_grad():
    torch.testing.assert_close(new(torch.cat([obs, scans], -1)), old(obs), atol=1e-6, rtol=1e-5)
