"""Divergent imagined trajectories must not corrupt critic running statistics."""

from copy import deepcopy
import math
from types import SimpleNamespace
from unittest.mock import Mock

import pytest
import torch

from go2_supermimic.supermimic import state as st
from go2_supermimic.supermimic.buffer import ReplayBuffer
from go2_supermimic.supermimic.train import Actor, Critic, TrainCfg, Trainer, _finite_rows
from go2_supermimic.supermimic.world_model import WorldModel
from go2_supermimic.target.terrain import SCAN_POINTS


def small_trainer():
  """Build the learner pieces without constructing a simulator or CUDA context."""
  torch.manual_seed(17)
  trainer = Trainer.__new__(Trainer)
  trainer.cfg = TrainCfg(
    device="cpu", num_envs=2, buffer_len=4, imag_batch=4, horizon=2,
    critic_epochs=1, critic_minibatches=1, compile=False,
  )
  trainer.dev = "cpu"
  trainer.actor = Actor(5, (8,), st.NUM_JOINTS)
  trainer.critic = Critic(7, (8,))
  trainer.wm = WorldModel((8,))
  trainer.opt_actor = torch.optim.Adam(trainer.actor.parameters(), lr=1e-3)
  trainer.opt_critic = torch.optim.Adam(trainer.critic.parameters(), lr=1e-3)
  trainer.buf = ReplayBuffer(2, 4, 5, "cpu", gen_dim=3)
  trainer.buf.add(
    torch.zeros(2, st.STATE_DIM), torch.zeros(2, 3),
    torch.zeros(2, st.NUM_JOINTS), torch.zeros(2, st.NUM_JOINTS),
    torch.ones(2, 5), torch.zeros(2, 3), torch.zeros(2, dtype=torch.bool),
    torch.zeros(2, SCAN_POINTS),
  )
  trainer.xi = torch.zeros(2, st.CONTEXT_DIM)
  trainer.enc_bias = torch.zeros(2, st.NUM_LEG_JOINTS)
  trainer.is_velocity = True
  trainer.it = 1
  trainer.actor_frozen_until = 10
  trainer.nonfinite_steps = 3

  # Use nontrivial running statistics and populated Adam state so the guard
  # must preserve a trained critic, not merely leave fresh zero state alone.
  x = torch.randn(6, 7)
  trainer.critic.norm.update(x)
  trainer.critic(x).square().mean().backward()
  trainer.opt_critic.step()
  trainer.opt_critic.zero_grad(set_to_none=True)
  return trainer


@pytest.mark.parametrize("source", ["critic_input", "target"])
@pytest.mark.parametrize("invalid_value", [float("nan"), float("inf")])
def test_nonfinite_imagination_leaves_critic_and_optimizer_unchanged(source, invalid_value):
  trainer = small_trainer()
  batch, horizon = trainer.cfg.imag_batch, trainer.cfg.horizon
  data = {
    "critic_in": torch.ones(batch, horizon + 1, 7),
    "rewards": torch.ones(batch, horizon),
    "surv": torch.ones(batch, horizon + 1),
  }
  targets = torch.ones(batch, horizon)
  if source == "critic_input":
    data["critic_in"][0, 0, 2] = invalid_value
  else:
    targets[0, 0] = invalid_value

  def rollout(wm, actor, critic, seed, hint):
    assert wm is trainer.wm and critic is trainer.critic and hint == 0.
    assert all(not parameter.requires_grad for parameter in wm.parameters())
    # Preserve a real actor autograd graph while isolating the critic guard.
    objective = actor(seed["obs"]).square().sum(dim=-1)
    return objective, data

  trainer.imag = SimpleNamespace(
    rollout=Mock(side_effect=rollout), gae_targets=Mock(return_value=targets),
  )
  critic_before = deepcopy(trainer.critic.state_dict())
  optimizer_before = deepcopy(trainer.opt_critic.state_dict())
  trainer.opt_critic.step = Mock(wraps=trainer.opt_critic.step)

  metrics = trainer.improve_policy()

  assert math.isnan(metrics["critic_loss"])
  assert math.isfinite(metrics["actor_grad_norm"])
  assert trainer.nonfinite_steps == 4
  assert all(parameter.requires_grad for parameter in trainer.wm.parameters())
  assert all(parameter.grad is None for parameter in trainer.wm.parameters())
  trainer.opt_critic.step.assert_not_called()
  trainer.imag.rollout.assert_called_once()
  trainer.imag.gae_targets.assert_called_once()
  torch.testing.assert_close(trainer.critic.state_dict(), critic_before, rtol=0, atol=0)
  torch.testing.assert_close(trainer.opt_critic.state_dict(), optimizer_before, rtol=0, atol=0)
  assert all(torch.isfinite(value).all() for value in trainer.critic.norm.state_dict().values())


def test_finite_rows_combines_tensors_and_all_non_batch_dimensions():
  state = torch.zeros(4, 2, 3)
  observations = torch.zeros(4, 5)
  state[1, 1, 2] = float("nan")
  observations[2, 0] = -float("inf")
  assert _finite_rows(state, observations).tolist() == [True, False, False, True]
