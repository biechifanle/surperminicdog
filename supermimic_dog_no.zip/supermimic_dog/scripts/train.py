"""Train a chase / dodge policy with SuperMimic.

Flat ground, from scratch:
  python scripts/train.py --task MID80-Chase-Flat --run-name mid80_flat

Basic forward/lateral/turning velocity tracking:
  python scripts/train.py --task MID80-Velocity-Flat --run-name mid80_velocity

Basic movement on 13 XML terrain types:
  python scripts/train.py --task MID80-Velocity-Terrain --run-name mid80_velocity_terrain

Terrain, warm-started from a trained MID80 flat policy:
  python scripts/train.py --task MID80-Chase-Terrain --resume <mid80 model.pt> --run-name terrain

The released Go2 weights and twelve-action MoE-CTS driver are incompatible.

Every TrainCfg field (go2_supermimic/supermimic/train.py) is a flag.
"""

import torch

from go2_supermimic.supermimic.train import main

if __name__ == "__main__":
  torch.set_float32_matmul_precision("high")
  main()
