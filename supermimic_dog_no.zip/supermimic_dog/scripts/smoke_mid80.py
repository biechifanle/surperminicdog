"""Check MID80 assets and learner; optionally run GPU simulation and one train step.

  python scripts/smoke_mid80.py
  python scripts/smoke_mid80.py --train-cpu
  python scripts/smoke_mid80.py --task MID80-Velocity-Flat --train-cpu
  python scripts/smoke_mid80.py --task MID80-Velocity-Terrain --train-cpu
  python scripts/smoke_mid80.py --device cuda:0

The CPU path runs native MuJoCo PD control and a learner backward pass. The CUDA
path also checks mjlab observations against imagination, then collects replay,
fits the world model, and updates the actor/critic once. Temporary training logs
and the checkpoint are removed after validation.
"""

from __future__ import annotations

import argparse
from pathlib import Path
import re
import sys
import tempfile

# Also allow invocation from a checkout before `pip install -e .`.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import mujoco
import numpy as np
import torch

from go2_supermimic.robot import constants as rc
from go2_supermimic.robot.mid80 import MID80_XML, get_mid80_robot_cfg
from go2_supermimic.supermimic import state as st
from go2_supermimic.supermimic.world_model import WorldModel
from go2_supermimic.target import interface as ti
from go2_supermimic.target.terrain import SCAN_POINTS


def check_xml_and_cpu_physics(steps: int) -> None:
  cfg = get_mid80_robot_cfg()
  spec = mujoco.MjSpec.from_file(str(MID80_XML))
  spec.worldbody.add_geom(name="smoke_ground", type=mujoco.mjtGeom.mjGEOM_PLANE,
                          size=[5, 5, 0.1], contype=1, conaffinity=2)
  model = spec.compile()
  assert (model.nq, model.nv) == (23, 22)
  ids = np.array([model.joint(name).id for name in rc.JOINT_NAMES])
  qids, vids = model.jnt_qposadr[ids], model.jnt_dofadr[ids]
  assert not model.jnt_limited[ids[12:]].any(), "wheel joints must rotate continuously"
  for name in rc.FOOT_GEOM_NAMES:
    assert np.isclose(model.geom(name).size[0], rc.WHEEL_RADIUS)
  assert model.body(rc.BASE_BODY_NAME).mass[0] > 0
  # Match the entity's terrain-only collision masks and actuator rotor inertia.
  for geom_id in range(model.ngeom):
    name = mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_GEOM, geom_id) or ""
    if name.endswith("_collision"):
      model.geom_contype[geom_id], model.geom_conaffinity[geom_id] = 2, 1
  actuators = [next(a for a in cfg.articulation.actuators
                    if any(re.fullmatch(expr, name) for expr in a.target_names_expr))
               for name in rc.JOINT_NAMES]
  kp = np.array([a.stiffness for a in actuators])
  kd = np.array([a.damping for a in actuators])
  effort = np.array([a.effort_limit for a in actuators])
  model.dof_armature[vids] = [a.armature for a in actuators]
  model.opt.timestep = 0.0025
  data = mujoco.MjData(model)
  data.qpos[:3] = cfg.init_state.pos
  mujoco.mj_forward(model, data)
  # Leg targets remain at the reference zero-angle stance; all wheels receive
  # a small velocity command. qfrc_applied avoids requiring actuators in the XML.
  target_velocity = np.zeros(16)
  target_velocity[12:] = 0.2 * rc.WHEEL_ACTION_SCALE
  peak_wheel_speed = 0.0
  for _ in range(max(100, steps)):
    tau = kp * (-data.qpos[qids]) + kd * (target_velocity - data.qvel[vids])
    data.qfrc_applied[vids] = np.clip(tau, -effort, effort)
    mujoco.mj_step(model, data)
    assert np.isfinite(data.qpos).all() and np.isfinite(data.qvel).all()
    peak_wheel_speed = max(peak_wheel_speed, float(np.abs(data.qvel[vids[12:]]).max()))
  assert peak_wheel_speed > 1e-3, "velocity commands did not turn the wheels"
  assert data.qpos[2] > 0.1, "reference PD stance collapsed during the CPU smoke check"
  print(f"PASS XML/native MuJoCo: nq={model.nq}, nv={model.nv}, "
        f"base_z={data.qpos[2]:.3f} m, peak_wheel_speed={peak_wheel_speed:.3f} rad/s")


def check_cpu_learner(task: str) -> None:
  import go2_supermimic.env  # noqa: F401
  from mjlab.tasks.registry import load_env_cfg

  cfg = load_env_cfg(task)
  terms = st.obs_terms(cfg)
  history = cfg.observations["actor"].history_length
  obs_dim = sum(dim for _, dim in terms) * history
  velocity = "velocity" in cfg.commands
  torch.manual_seed(0)
  batch = 4
  s = torch.zeros(batch, st.STATE_DIM)
  s[:, st.Z] = 0.42
  s[:, st.GRAV] = torch.tensor([0., 0., -1.])
  action = torch.randn(batch, st.NUM_JOINTS) * 0.1
  extra = {"velocity_command": torch.zeros(batch, 3)} if velocity else {}
  if "lidar" in dict(terms):
    extra["lidar"] = torch.zeros(batch, dict(terms)["lidar"])
  if "height_scan" in dict(terms):
    extra["height_scan"] = torch.zeros(batch, dict(terms)["height_scan"])
  frame = st.obs_frame(s, action, None if velocity else torch.zeros(batch, ti.DIM),
                       torch.zeros(batch, 12), noise=False, **extra)
  obs = st.push_history(torch.zeros(batch, obs_dim), frame, history, terms)
  assert obs.shape == (batch, obs_dim)
  scan_dim = 0 if velocity else SCAN_POINTS
  model = WorldModel((32, 32), scan_dim=scan_dim)
  xi = torch.zeros(batch, st.CONTEXT_DIM)
  relief = torch.zeros(batch, scan_dim)
  next_s, delta = model(s, action, torch.zeros_like(action), xi, relief)
  assert next_s.shape == (batch, 74) and delta.shape == (batch, 3)
  loss = (next_s - s).square().mean() + delta.square().mean()
  optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
  loss.backward()
  assert torch.isfinite(loss)
  assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())
  optimizer.step()
  print(f"PASS CPU learner {task}: state=74, actions=16, actor_obs={obs_dim}, loss={loss.item():.6f}")


def _assert_latest_observations(env, obs, cfg) -> None:
  velocity = "velocity" in cfg.commands
  term = env.command_manager.get_term("velocity" if velocity else "target")
  terms = st.obs_terms(cfg)
  names = {name for name, _ in terms}
  state = st.robot_state(env, field=getattr(term, "height_field", None))
  if velocity:
    assert terms == st.VELOCITY_OBS_TERMS and "height_scan" not in names
  frame = st.obs_frame(
    state, env.action_manager.action,
    None if velocity else term.command, st.leg_encoder_bias(env.scene["robot"]), noise=False,
    lidar=term.lidar() if "lidar" in names else None,
    height_scan=term.scan() if "height_scan" in names else None,
    velocity_command=term.command if velocity else None,
  )
  history = cfg.observations["actor"].history_length
  offset = 0
  for name, dim in terms:
    latest = obs["actor"][:, offset + (history - 1) * dim:offset + history * dim]
    torch.testing.assert_close(latest, frame[name], atol=2e-5, rtol=2e-5,
                                msg=f"real/imagined observation mismatch: {name}")
    offset += history * dim
  assert obs["actor"].shape == (env.num_envs, offset)


def check_mjlab_env(device: str, task: str, steps: int, num_envs: int) -> None:
  import go2_supermimic.env  # noqa: F401
  from mjlab.envs import ManagerBasedRlEnv
  from mjlab.tasks.registry import load_env_cfg

  cfg = load_env_cfg(task)
  cfg.scene.num_envs = num_envs
  cfg.observations["actor"].enable_corruption = False
  env = ManagerBasedRlEnv(cfg=cfg, device=device)
  try:
    obs, _ = env.reset()
    consts = st.robot_consts(env)
    assert consts.action_scale.shape == (num_envs, 16)
    assert st.ContextReader(env).read().shape == (num_envs, st.CONTEXT_DIM)
    _assert_latest_observations(env, obs, cfg)
    for _ in range(steps):
      action = 0.05 * torch.randn(num_envs, 16, device=device)
      obs, reward, terminated, truncated, _ = env.step(action)
      assert torch.isfinite(obs["actor"]).all() and torch.isfinite(reward).all()
      _assert_latest_observations(env, obs, cfg)
    print(f"PASS mjlab {task}: {num_envs} envs x {steps} steps, "
          f"obs={obs['actor'].shape[-1]}, real/imagined observations match")
  finally:
    env.close()


def check_tiny_train(device: str, task: str, num_envs: int) -> None:
  from go2_supermimic.supermimic.train import TrainCfg, Trainer

  with tempfile.TemporaryDirectory(prefix="mid80-smoke-") as log_root:
    cfg = TrainCfg(
      task=task, device=device, num_envs=num_envs, iterations=1, warmup_iterations=0,
      buffer_len=16, wm_window=2, wm_batch=8, wm_updates=1,
      wm_hidden=(32, 32), actor_hidden=(32, 32), critic_hidden=(32, 32),
      horizon=2, imag_batch=8, critic_epochs=1, critic_minibatches=1,
      archive_size=16, compile=False, log_interval=1, save_interval=1,
      log_root=log_root, run_name="mid80_smoke",
    )
    trainer = Trainer(cfg)
    try:
      if trainer.is_velocity:
        assert trainer.obs.shape[-1] == 265
        assert trainer.wm.scan_dim == trainer.buf.relief.shape[-1] == 0
        assert trainer.archive.data["relief"].shape[-1] == 0
        assert trainer.critic.norm.mean.shape[0] == 81
      actor_before = [p.detach().clone() for p in trainer.actor.parameters()]
      trainer.run()
      assert trainer.nonfinite_steps == 0, "nonfinite gradient updates were skipped"
      assert trainer.last_ckpt is not None and trainer.last_ckpt.is_file()
      assert any(not torch.equal(old, new) for old, new in zip(actor_before, trainer.actor.parameters()))
      checkpoint = torch.load(trainer.last_ckpt, map_location="cpu", weights_only=False)
      st.validate_checkpoint_robot(checkpoint)
      assert checkpoint["task_type"] == trainer.task_type
      assert checkpoint["history"] == trainer.history
      assert tuple(checkpoint["obs_terms"]) == trainer.terms
      # Check the actual resume path, including restoration after weights changed.
      learned = [p.detach().clone() for p in trainer.actor.parameters()]
      with torch.no_grad():
        next(trainer.actor.parameters()).add_(1.0)
      trainer.load(str(trainer.last_ckpt))
      assert all(torch.equal(old, new) for old, new in zip(learned, trainer.actor.parameters()))
      # A checkpoint with other command semantics must fail before loading any
      # network, even if its actor tensor shapes happen to match.
      incompatible = dict(checkpoint)
      incompatible["task_type"] = "chase" if trainer.task_type == "velocity" else "velocity"
      incompatible_path = Path(log_root) / "wrong-task.pt"
      torch.save(incompatible, incompatible_path)
      try:
        trainer.load(str(incompatible_path))
      except ValueError as error:
        assert "task type" in str(error)
      else:
        raise AssertionError("cross-task checkpoint was accepted")
      assert all(torch.equal(old, new) for old, new in zip(learned, trainer.actor.parameters()))
      print("PASS tiny training: replay collection, world model, actor/critic update, "
            "MID80 checkpoint resume and cross-task rejection")
    finally:
      trainer.writer.close()
      trainer.env.close()


def main() -> None:
  parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
  parser.add_argument("--device", default="cpu", choices=("cpu", "cuda:0"))
  parser.add_argument("--task", default="MID80-Chase-Flat",
                      choices=("MID80-Chase-Flat", "MID80-Chase-Obstacles", "MID80-Chase-Terrain",
                               "MID80-Velocity-Flat", "MID80-Velocity-Terrain"))
  parser.add_argument("--steps", type=int, default=20)
  parser.add_argument("--num-envs", type=int, default=4)
  parser.add_argument("--train-cpu", action="store_true", help="also run mjlab and tiny training on CPU (slow on first use)")
  parser.add_argument("--skip-train", action="store_true", help="skip tiny training after the mjlab rollout")
  args = parser.parse_args()
  if args.steps < 1 or args.num_envs < 1:
    parser.error("--steps and --num-envs must be positive")
  check_xml_and_cpu_physics(args.steps)
  check_cpu_learner(args.task)
  if args.device != "cpu":
    if not torch.cuda.is_available():
      parser.error("CUDA is unavailable; CPU checks passed, but mjlab GPU rollout/training needs an NVIDIA GPU")
  if args.device != "cpu" or args.train_cpu:
    check_mjlab_env(args.device, args.task, args.steps, args.num_envs)
    if not args.skip_train:
      check_tiny_train(args.device, args.task, args.num_envs)


if __name__ == "__main__":
  main()
