# Go2-SuperMimic: Agile Chasing and Dodging on a Unitree Go2

> **本工作区已切换为 MID80 轮足机器人。** 以下原版 Go2 说明保留作背景；
> `MID80-Chase-Flat/Obstacles/Terrain` 使用新模型，旧 `Go2-Chase-*` 名称也指向 MID80。
> 原 `weights/*.pt` 的 12 维 Go2 策略不能用于这台 16 维轮足机器人，请从头训练。

```bash
pip install -e '.[dev]'  # Python >= 3.10；训练需要可用的 NVIDIA/CUDA 设备
python scripts/smoke_mid80.py  # CPU: XML、动力学和世界模型检查
python scripts/smoke_mid80.py --train-cpu  # CPU: 实际环境步进及一轮训练检查
python scripts/smoke_mid80.py --device cuda:0  # GPU: 环境 rollout 和短训练
python scripts/train.py --task MID80-Chase-Flat --num-envs 1024 --run-name mid80_flat
```

新增独立的基础移动任务 **`MID80-Velocity-Flat`**，原追球任务和上述训练指令保持不变。
新任务在平地跟踪机身航向坐标系下的前后速度、左右速度和转向角速度：
`vx ∈ [-0.5, 1.0] m/s`、`vy ∈ [-0.3, 0.3] m/s`、`wz ∈ [-1, 1] rad/s`。
每 4–8 秒更换指令，10% 场景使用零指令练习站立。继续使用 SuperMimic，
奖励以速度跟踪、保持直立和动作平稳为主，不生成追球或躲避目标。

```bash
python scripts/train.py --task MID80-Velocity-Flat --num-envs 1024 --run-name mid80_velocity
python scripts/smoke_mid80.py --task MID80-Velocity-Flat --train-cpu
python scripts/eval.py MID80-Velocity-Flat --checkpoint <model.pt> --num-envs 64 --seconds 30
```

基础移动的动作仍为 16 维、缩放不变；观测为每帧 53 维、5 帧共 **265 维**。
最后 3 维为速度指令，缩放 `(2, 2, 1)`，其余关节与惯性观测沿用现有配置。
追球与基础速度任务的策略输入及奖励不同，checkpoint 分别保存使用；不可直接交叉恢复策略。

多地形基础移动任务 **`MID80-Velocity-Terrain`** 现使用盲走策略，原平地训练指令继续使用。
物理碰撞地形来自 `deep_robotics_model/mid80wheeldog/mjcf/terrains.xml`。
`scene_terrain.xml` 是包含机器人和全部地形的独立 MuJoCo 查看场景；机器人本体仍由
`mid80.xml` 加载，防止并行环境重复添加地面。

| 地形名 | 尺寸（单位 m） |
|---|---|
| `flat` | 平地 |
| `rough` | 0.4 × 0.4 的凹凸格，表面高差约 −0.03 至 0.05 |
| `stairs_1` / `stairs_2` / `stairs_3` / `stairs_4` / `stairs_5` | 每级高度 0.04 / 0.06 / 0.08 / 0.10 / 0.12，踏面宽度依次 0.50 / 0.45 / 0.40 / 0.35 / 0.30；每组 5 级 |
| `slope` | 10° 斜面及顶部平段，可练习上坡和下坡 |
| `platform_1` / `platform_2` / `platform_3` / `platform_4` / `platform_5` | 高度 0.08 / 0.12 / 0.16 / 0.20 / 0.24，台面 1.2 × 4 |

共 13 类，每块 8 × 6 m，中心保留平整出生区。每次重置随机选择地形；走到该块边缘时
按超时重置，不计作摔倒。速度指令范围、16 维动作及动作缩放沿用平地任务。
策略不使用高度扫描、图像或深度输入；每帧 **53 维**，5 帧共 **265 维**，仅包含机身角速度、
投影重力、12 个腿关节位置、16 个关节速度、上一帧 16 维动作以及 3 维速度指令。
训练时仍用机身中心点下的地面高度计算机身高度奖励和世界模型状态，这些训练用数据不进入
策略观测。世界模型和价值网络也不接收 77 点高度扫描，环境中不再运行足端高度射线传感器，
保留接触传感器。地形、奖励、动作缩放和物理参数保持不变。

```bash
# 从头训练基础多地形盲走，累计 40000 次迭代
python scripts/train.py --task MID80-Velocity-Terrain --num-envs 1024 --iterations 40000 --run-name mid80_velocity_terrain_blind_40k
# 或使用 265 维平地速度策略初始化多地形盲走
python scripts/train.py --task MID80-Velocity-Terrain --resume <velocity_flat_model.pt> --num-envs 1024 --iterations 40000 --run-name mid80_velocity_terrain_blind_40k
python scripts/smoke_mid80.py --task MID80-Velocity-Terrain --train-cpu
python scripts/eval.py MID80-Velocity-Terrain --checkpoint <model.pt> --terrain stairs_3 --num-envs 1 --seconds 30
python deep_robotics_model/mid80wheeldog/generate_terrain.py --validate
```

旧的 **650 维带扫描多地形 checkpoint 不能直接续训或运行当前盲走任务**；请重新训练，
或使用 265 维平地速度策略初始化。追球策略不能用于速度任务。上述地形覆盖和短训练检查
仅验证训练链路，实际跨越全部台阶及高台的能力需要训练后逐项评估。

盲走训练中断后可从本次盲走运行保存的检查点续训，`--iterations 40000` 表示累计训练到第 40000 次迭代：

```bash
python scripts/train.py --task MID80-Velocity-Terrain --num-envs 1024 \
  --resume 'logs/supermimic/<盲走运行目录>/model_4000.pt' --continue-run true \
  --iterations 40000 --run-name mid80_velocity_terrain_blind_40k_resume
```

多地形采样已保护异常坐标的数组索引；物理状态出现 NaN/Inf 时，通过 `nan_state` 终止并
重置对应环境，排除跨重置的世界模型监督。日志中的 `nan_state` 表示物理异常终止，
`nonfinite_reset` 表示末尾观测检查触发的额外重置。策略自身输出非有限动作时会明确报错，
避免将损坏的动作写入回放。CUDA device-side assert 发生后需退出原 Python 进程，再运行续训命令。

**手柄 sim2sim（原生 MuJoCo 实时窗口）**：单独运行 `scripts/sim2sim.py`，使用训练得到的
265 维 `MID80-Velocity-Terrain` 盲走 checkpoint。仿真和策略推理都在 CPU 上执行，不启动 mjlab/Warp
训练环境。需要仓库中的机器人与地形 XML，以及当前环境已有的 `mujoco`、`torch`、`numpy`；
Linux 手柄通过 `/dev/input/js0` 读取，无需额外安装 pygame。

```bash
python scripts/sim2sim.py \
  --checkpoint 'logs/supermimic/<盲走运行目录>/model_40000.pt' \
  --terrain flat \
  --joystick /dev/input/js0
```

请将 `<盲走运行目录>` 替换为新盲走训练的实际目录，旧的 650 维 checkpoint 不兼容。场景同时加载全部 13 类地形，
`--terrain` 选择出生区域；可以行驶到相邻区域，或用手柄切换并复位到该地形的平整中心。
窗口会跟随机器人，并显示速度指令与启用状态。需要本地图形桌面，普通 SSH 无显示环境下用
下方 `--headless` 检查控制链路。

| 默认 Xbox 按键 | 功能 |
|---|---|
| 左摇杆上下 / 左右 | 前后 / 横移 |
| 右摇杆左右 | 转向 |
| A | 启用摇杆移动指令 |
| B / 键盘空格 | 立即将速度指令置零，由策略控制站立 |
| X / R | 在当前选择的地形中心复位 |
| LB、RB / P、N | 切换上一种、下一种地形并复位 |
| Back / Q | 退出 |

启动、复位或手柄断开后，速度指令保持为零；重连后需再次按 A。原始策略动作不做额外裁剪，
仅按训练配置限制电机力矩。默认速度范围为前进 1、后退 0.5、横移 ±0.3 m/s，转向 ±1 rad/s，
带摇杆死区和指令平滑。物理步长 0.005 s，策略每 4 步执行一次（50 Hz）；265 维盲走观测、历史
顺序、关节顺序与缩放均与训练对齐，策略推理不读取地形高度。使用名义摩擦、质量和零编码器偏差，
不复现训练时的参数随机化；原生 MuJoCo 和 Warp 的接触轨迹可能存在差异。

手柄布局不同时，先查看轴和按键编号，再覆盖映射（`--axes` 顺序为前后、横移、转向）：

```bash
python scripts/sim2sim.py --list-gamepad
# 例如某些 PS 手柄的右摇杆横轴是 2：在启动命令末尾追加
# --axes 1 0 2 --axis-signs -1 -1 -1
# 单独覆盖按键示例：--enable-button 0 --stop-button 1 --reset-button 2

# 无手柄、无窗口，使用固定前进指令验证实际策略（5 秒）
python scripts/sim2sim.py \
  --checkpoint 'logs/supermimic/<盲走运行目录>/model_40000.pt' \
  --terrain stairs_3 --headless --seconds 5 --command 0.5 0 0
```

默认执行器目标延迟每个物理步随机取 0–2 步，与训练一致。使用 `--delay-steps 0` 可测试无延迟，
`--seed` 可控制随机序列。摔倒或离开整个地图时自动复位；`--no-auto-reset` 可关闭自动复位。

MID80 模型入口是 `deep_robotics_model/mid80wheeldog/mjcf/mid80.xml`，从同目录下的
原始 URDF 转换，保留连杆质量、惯量、关节轴和限位，四轮用半径 0.079 m 的圆柱接触。
初始关节角全为 0，机身高度设为 0.42 m，避免零姿态轮子穿入地面。
参考配置的腿部位置动作缩放为 0.25，轮子速度动作缩放为 5.0；
腿部 PD 为 40/2、力矩上限 80 Nm，轮速控制增益为 0.6、力矩上限 90 Nm。
执行器采用有力矩限幅和 0–2 步延迟的 PD 控制；参考资产的额定速度 20/28 rad/s
没有作为额外硬速度约束，和该资产的显式 PD 控制方式一致。

动作/关节速度顺序固定为 `fl, fr, rl, rr` 每腿的 `abad, hip, knee`，再接四个
`wheel`。位置观测仅包含 12 个腿关节，16 个关节速度观测乘以 0.05。
沿用追球任务的目标观测、投影重力、50 Hz 控制频率和 5 帧历史，因此每帧为 78 维，平地/障碍/地形
总输入分别为 **390/470/775** 维；世界模型状态为 74 维。
参考 Isaac Lab 配置中的速度指令、步态相位、Euler 角和 15 帧历史属于另一套任务，
本次保留现有追球/躲避任务和训练算法，不直接导入该配置文件。
解析碰撞检测同步机身尺寸与轮半径；轮胎采用轮心球形包络，因此侧向判定偏保守。
重新生成 XML 可运行 `python deep_robotics_model/mid80wheeldog/convert_urdf.py --validate`。

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Python](https://img.shields.io/badge/python-3.10%2B-blue.svg)](https://www.python.org/)
[![Built on mjlab](https://img.shields.io/badge/built%20on-mjlab-orange.svg)](https://github.com/mujocolab/mjlab)

Ziyue Zheng, Johns Hopkins University

Simulation tasks and training code for a Unitree Go2 that **chases** a fleeing ball while
**dodging** balls and bars thrown at it, on flat ground, among obstacles and on rough terrain.
Training is model-based: our re-implementation of
[SuperMimic](https://arxiv.org/abs/2610.28480) (a learned world model plus back-propagation
through imagined rollouts) on [mjlab](https://github.com/mujocolab/mjlab) (MuJoCo Warp).

## 📖 Overview

| Flat | Obstacles | Terrain |
|:---:|:---:|:---:|
| <img src="resources/flat.gif" width="280"/> | <img src="resources/obstacles.gif" width="280"/> | <img src="resources/terrain.gif" width="280"/> |
| `Go2-Chase-Flat` | `Go2-Chase-Obstacles` | `Go2-Chase-Terrain` |

Every task combines the same two games:

- **Chase.** The green ball flees at about the robot's speed, jukes sideways and stays in an
  arena. Touching it with the head is a *tag*; the ball then breaks free and runs again.
- **Dodge.** Obstacles are thrown from around the chase ball, one at a time and with no
  wind-up: high, mid and low **balls** (duck, sidestep, lift a leg), **low bars** to jump over
  and **high bars** to duck under.

| Task | Scene | Extra robot input | Episode modes | Thrown |
|---|---|---|---|---|
| `Go2-Chase-Flat` | open flat ground | – | chase / dodge / both (30 / 30 / 40 %) | balls + bars |
| `Go2-Chase-Obstacles` | tall boxes, pillars and walls, placed per episode | 16-ray planar LiDAR | chase / dodge / both (30 / 30 / 40 %) | balls + bars (slower) |
| `Go2-Chase-Terrain` | pyramid stairs up and down, box grids, rough ground, slopes; 5 difficulty rows | 11 × 7 height scan | chase / chase + dodge (60 / 40 %) | bars |

Among obstacles the chase ball slides along them and throws wait for a clear line to the robot.
On terrain, steps grow from 2 to 10 cm and box edges from 2 to 8 cm; harder rows open during
training.

## 🚀 Quickstart

```bash
pip install -e .        # needs mjlab >= 1.6 (MuJoCo Warp, CUDA GPU)
python -m pytest tests  # generator, collision model, obstacles, height scan, warm starts

# Watch the pretrained policies.
python scripts/eval.py Go2-Chase-Flat --checkpoint weights/flat.pt --mode both \
    --num-envs 1 --seconds 30 --video flat.mp4
python scripts/eval.py Go2-Chase-Obstacles --checkpoint weights/obstacles.pt --mode both \
    --num-envs 1 --seconds 30 --video obstacles.mp4
python scripts/eval.py Go2-Chase-Terrain --checkpoint weights/terrain.pt --terrain stairs \
    --num-envs 1 --seconds 30 --video terrain.mp4
```

### Pretrained policies

`weights/` holds the actor of each task (policy only; enough for `scripts/eval.py`, not for
resuming training, which also needs the world model and critic).

| file | task | inputs |
|---|---|---|
| `flat.pt` | `Go2-Chase-Flat` | 350 |
| `obstacles.pt` | `Go2-Chase-Obstacles` | 430 |
| `terrain.pt` | `Go2-Chase-Terrain` | 735 |

### Train

```bash
# Flat ground, from scratch (see "How the released policies were trained" on length).
python scripts/train.py --task Go2-Chase-Flat --run-name flat
# Extend a run: resume it and carry on its iteration count, curricula and schedules.
python scripts/train.py --task Go2-Chase-Flat --resume logs/supermimic/<flat>/model_12000.pt \
    --continue-run true --iterations 30000 --run-name flat_cont

# Obstacles, warm-started from the flat policy (its new LiDAR inputs start at zero weight).
python scripts/train.py --task Go2-Chase-Obstacles --resume logs/supermimic/<flat>/model_12000.pt \
    --run-name obstacles

# Terrain, warm-started from the flat policy (new height-scan inputs start at zero weight).
# Two drivers keep collecting world-model data throughout (they shape the data only; the
# trained and deployed policy is the actor alone): a terrain-walking policy (steady steps on
# edges and slopes) and the flat policy itself (jumps and ducks on terrain).
# Terrain rows and ball speed ramp up over 12k iterations.
python scripts/train.py --task Go2-Chase-Terrain --resume logs/supermimic/<flat>/model_12000.pt \
    --driver-policy <MoE-CTS policy.pt> --driver-frac 0.1 \
    --expert-policy logs/supermimic/<flat>/model_12000.pt --expert-frac 0.1 \
    --wm-updates 4 --actor-lr-scale 0.3 --warmup-iterations 1000 --run-name terrain
```

The terrain-walking driver is go2_rl_lab's mixed-terrain MoE-CTS policy (MIT), not included
here: download `exported/policy.pt` from
[wty-yy/go2_rl_gym_data](https://huggingface.co/wty-yy/go2_rl_gym_data/tree/main/go2_rl_lab/2026-10-13_15-35-09_mixed1.3.2resume_82.5k_0.6929).

Every field of `TrainCfg` (`go2_supermimic/supermimic/train.py`) is a command-line flag. On a
16 GB GPU use `--num-envs 2048 --imag-batch 4096 --buffer-len 400` for terrain.

### How the released policies were trained

All three were trained from scratch with SuperMimic in this setup, with no demonstrations and
no PPO; only the terrain runs used other policies, and only to collect world-model data.

- **Flat** (`flat.pt`): tens of thousands of iterations in total, in stages that each
  resumed the previous checkpoint while the task grew: chasing only, then thrown balls, then
  bars, then throws from around the chase ball. It was trained with an earlier version of
  this code; the released task is the final stage (checked against it config by config and
  by evaluation). A single run of the final task from scratch is still being checked: after
  ~7k iterations it chases and rarely falls, but it is still hit by bars far more often, so
  expect to need longer runs (or the staged route) to match `flat.pt`.
- **Obstacles** (`obstacles.pt`): resumed from the flat policy, about 8k iterations.
- **Terrain** (`terrain.pt`): resumed from the flat policy; about 12k iterations on gentler,
  continuous terrain, then about 25k on the current terrain across several restarts while
  fixing problems (a higher fall penalty, bars that come from uphill, a finer height map,
  keeping the data drivers on, a lower actor learning rate); the last 12k ran with the
  command above. Earlier stages used other settings, so this is the setup we ended with, not
  a single run we have reproduced end to end.

### Evaluate and record

```bash
# Metrics over many envs at the hardest settings: tags / min, per-kind dodge hit rates with
# body height, top foot and sideways speed, obstacle contact, falls / min, speed.
python scripts/eval.py Go2-Chase-Flat --checkpoint model.pt --num-envs 256 --seconds 60

# A video of env 0 with a status card (mode, robot and ball speeds).
python scripts/eval.py Go2-Chase-Obstacles --checkpoint model.pt --mode both \
    --num-envs 1 --seconds 30 --video obstacles.mp4
python scripts/eval.py Go2-Chase-Terrain --checkpoint model.pt --terrain stairs \
    --num-envs 1 --seconds 30 --video stairs.mp4
```

`--mode chase|dodge|both|mixed` overrides the task's episode modes; `--terrain` puts env 0 on
one terrain type (`flat`, `stairs`, `stairs_inv`, `boxes`, `rough`, `slope`, `slope_inv`).

## 🔌 Interfaces

The following tables describe the original Go2 chase tasks. For the current MID80
velocity tasks, use the 265-dimensional blind observation layout documented above;
`MID80-Velocity-Terrain` does not include a height scan.

**Policy.** `Actor` (`go2_supermimic/supermimic/train.py`): an MLP from the stacked actor
observation to 12 joint-position actions (target = default pose + action × per-joint scale, PD
control at 50 Hz). Checkpoints hold `actor`, `critic`, `world_model` and the training config.

**Actor observation**, 5 frames of history, each term stacked oldest → newest:

| term | per frame | notes |
|---|---|---|
| base angular velocity | 3 | IMU, body frame |
| projected gravity | 3 | body frame |
| joint positions − default | 12 | with a per-episode encoder bias |
| joint velocities | 12 | |
| last action | 12 | |
| target | 28 | the two slots below |
| LiDAR | 16 | obstacles task only; ranges to 4 m |
| height scan | 77 | terrain task only; base height above an 11 × 7 grid, 12 cm spacing |

Total: 350 (flat), 430 (obstacles), 735 (terrain) inputs. No linear velocity: it is not
measured on the robot.

**Target observation** (`go2_supermimic/target/interface.py`), the only thing the policy knows
about the balls: two slots, CHASE then DODGE, in the robot yaw frame. In simulation they are
filled from ground truth (`oracle_observation`); on the robot a perception stack must fill the
same layout.

| per slot (14) | meaning |
|---|---|
| `p` (3), `v` (3) | object position relative to the base and its velocity, yaw frame |
| `sigma` (3) | 1-σ position uncertainty (0 for the oracle) |
| `visible`, `age` | measured this step; seconds since the last measurement |
| `is_bar`, `half_len` | bar or ball; bar half length |
| `active` | the object is in play (an inactive slot is all zeros) |

## 📦 Package layout

```
go2_supermimic/
  robot/        go2.py (actuators, collisions), go2.xml + meshes (MuJoCo Menagerie)
  target/       generator.py   chase ball and dodge obstacles (pure `advance`, shared with imagination)
                collision.py   trunk box + leg capsules, hit clearance, tag and dodge reward helpers
                interface.py   the two-slot target observation
                obstacles.py   static obstacles: layout, 2D geometry, LiDAR, line of sight
                terrain.py     height field and the local height scan (terrain + obstacles)
  env/          env_cfg.py     the three tasks
                command.py     target command term (balls, hits, curricula, debug drawing)
                mdp.py         observation, reward and curriculum terms
                terrains.py    terrain mix and scene look
  supermimic/   world_model.py, buffer.py, imagine.py (analytic rewards, soft survival),
                train.py (collect / fit world model / improve policy), driver.py (terrain data)
  viz.py        video look and status card
scripts/        train.py, eval.py
tests/          no simulator needed
weights/        pretrained policies (actor only)
resources/      demo GIFs
```

## ⚠️ Limitations

- Simulation only. Nothing here has run on a physical Go2 yet.
- Perception is ground truth: the target slots are filled from the simulator. On the robot
  they must come from a detector; simulated sensor noise and dropouts
  are not part of the released tasks.
- Terrain is harder than flat ground: with all rows (steps up to 10 cm) and the fastest ball,
  `weights/terrain.pt` falls about 0.6 times a minute and is hit by about one in ten low bars;
  on the easier rows about 0.3 falls a minute. Training continues.
- The training recipes have not each been reproduced end to end from scratch (see "How the
  released policies were trained").

## 📚 Citation

This repository re-implements the training method of SuperMimic; please cite the paper:

```bibtex
@article{liao2026supermimic,
  title   = {SuperMimic: Scaling Humanoid Whole-Body Control with One Differentiable World Model},
  author  = {Liao, Qiayuan and Shao, Yiyang and Long, Junfeng and Zakka, Kevin and
             Horowitz, Roberto and Abbeel, Pieter and Sreenath, Koushil},
  journal = {arXiv preprint arXiv:2610.28480},
  year    = {2026}
}
```

## 🙏 Acknowledgements

- [SuperMimic](https://supermimic.github.io) (Liao et al., 2026) for the training method.
- [mjlab](https://github.com/mujocolab/mjlab) and MuJoCo Warp for simulation.
- [MuJoCo Menagerie](https://github.com/google-deepmind/mujoco_menagerie) for the Go2 model.
- [go2_rl_lab](https://github.com/wty-yy/go2_rl_gym) (MoE-CTS, Tianyang Wu) for the terrain
  policy used to collect world-model data.
- [SPIKE Lab](https://spike-lab.org) at Johns Hopkins University for its support.
- [Claude Code](https://www.anthropic.com/claude-code) (Anthropic), which helped write and
  debug much of this code.

## 📄 License

MIT (see [LICENSE](LICENSE)). The Go2 model and meshes in `go2_supermimic/robot/` come from
MuJoCo Menagerie and keep their own license
([LICENSE_menagerie_go2](go2_supermimic/robot/LICENSE_menagerie_go2)).


python scripts/sim2sim.py \
  --checkpoint logs/supermimic/2026-11-12_07-07-13_mid80_velocity_terrain_blind_40k/model_39000.pt \
  --terrain flat \
  --joystick /dev/input/js0