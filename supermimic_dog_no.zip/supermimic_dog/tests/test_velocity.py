"""Basic movement task boundaries, reward gradients and checkpoint isolation."""

import math
from dataclasses import fields
from types import SimpleNamespace

import pytest
import torch

from go2_supermimic.locomotion import COMMAND_SCALE, VELOCITY_TASK
from go2_supermimic.supermimic import state as st
from go2_supermimic.supermimic.driver import validate_checkpoint_task
from go2_supermimic.supermimic.imagine import ImagineCfg
from go2_supermimic.supermimic.velocity_imagine import VelocityImagination, VelocityRewardWeights


def _imagination(n=2):
  consts = st.RobotConsts(
    default_q=torch.zeros(n, 12),
    action_scale=torch.tensor([0.25] * 12 + [5.0] * 4).expand(n, -1),
    kp=torch.tensor([40.0] * 12 + [0.0] * 4),
    kd=torch.tensor([2.0] * 12 + [1.0] * 4),
    effort=torch.tensor([80.0] * 12 + [20.0] * 4),
    soft_limits=torch.tensor([-1.0, 1.0]).expand(n, 12, 2),
  )
  imagine = VelocityImagination(
    ImagineCfg(horizon=2, weights=VelocityRewardWeights()), consts, history=5, device="cpu",
  )
  k = {"default_q": consts.default_q, "action_scale": consts.action_scale,
       "soft_limits": consts.soft_limits}
  s = torch.zeros(n, st.STATE_DIM)
  s[:, st.Z] = 0.42
  s[:, st.GRAV] = torch.tensor([0.0, 0.0, -1.0])
  return imagine, k, s


def test_velocity_task_is_independent_and_keeps_chase_default():
  import go2_supermimic.env  # noqa: F401
  from mjlab.tasks.registry import load_env_cfg
  from go2_supermimic.supermimic.train import TrainCfg

  velocity = load_env_cfg(VELOCITY_TASK)
  chase = load_env_cfg("MID80-Chase-Flat")
  alias = load_env_cfg("Go2-Chase-Flat")
  assert TrainCfg().task == "MID80-Chase-Flat"
  assert set(velocity.commands) == {"velocity"}
  assert set(chase.commands) == {"target"}
  assert set(alias.commands) == {"target"}
  assert tuple(velocity.observations["actor"].terms) == tuple(n for n, _ in st.VELOCITY_OBS_TERMS)
  assert st.obs_terms(velocity) == st.VELOCITY_OBS_TERMS
  assert st.obs_terms(chase) == st.OBS_TERMS
  assert sum(d for _, d in st.obs_terms(velocity)) * 5 == 265
  assert sum(d for _, d in st.obs_terms(chase)) * 5 == 390
  assert velocity.observations["actor"].history_length == chase.observations["actor"].history_length == 5
  assert velocity.observations["actor"].terms["velocity_command"].scale == COMMAND_SCALE
  assert set(velocity.rewards) == {field.name for field in fields(VelocityRewardWeights)}
  for field in fields(VelocityRewardWeights):
    assert velocity.rewards[field.name].weight == getattr(VelocityRewardWeights(), field.name)
  assert "chase_approach" in chase.rewards and "evade_danger" in chase.rewards
  assert velocity.rewards["base_height_low"].params["min_height"] == 0.28
  assert chase.rewards["base_height_low"].params["min_height"] == 0.18
  assert not velocity.curriculum
  assert set(velocity.scene.entities) == {"robot"}
  assert tuple(velocity.actions) == tuple(chase.actions) == ("joint_pos", "joint_vel")
  assert velocity.actions["joint_pos"].scale == chase.actions["joint_pos"].scale == 0.25
  assert velocity.actions["joint_vel"].scale == chase.actions["joint_vel"].scale == 5.0
  # Registry loads must not share mutable actor/reward dictionaries across tasks.
  velocity.observations["actor"].terms.clear()
  assert "target" in load_env_cfg("MID80-Chase-Flat").observations["actor"].terms
  assert "velocity_command" in load_env_cfg(VELOCITY_TASK).observations["actor"].terms


def test_velocity_observation_scales_command_once_and_keeps_term_history():
  _, _, s = _imagination()
  command = torch.tensor([[0.4, -0.2, 0.7], [-0.1, 0.3, -0.5]])
  action = torch.randn(2, 16)
  frame = st.obs_frame(s, action, None, torch.zeros(2, 12), noise=False,
                       velocity_command=command)
  assert "target" not in frame
  assert torch.equal(frame["velocity_command"], command * torch.tensor(COMMAND_SCALE))
  history = torch.randn(2, 265)
  advanced = st.push_history(history, frame, 5, st.VELOCITY_OBS_TERMS)
  offset = 0
  for name, dim in st.VELOCITY_OBS_TERMS:
    old = history[:, offset:offset + 5 * dim]
    new = advanced[:, offset:offset + 5 * dim]
    assert torch.equal(new[:, :-dim], old[:, dim:])
    assert torch.equal(new[:, -dim:], frame[name])
    offset += 5 * dim
  assert offset == 265


def test_velocity_tracking_matches_simulator_at_rotated_heading_and_has_gradients():
  from go2_supermimic.env import velocity_mdp

  imagine, k, s0 = _imagination()
  command = torch.tensor([[0.6, -0.2, 0.3]]).expand(2, -1)
  s1 = s0.clone()
  s1[:, st.V_YAW] = torch.tensor([[0.6, -0.2, 0.0], [-0.1, 0.4, 0.2]])
  s1[:, st.W_B] = torch.tensor([[0.0, 0.0, 0.3], [0.0, 0.0, -0.4]])
  s1.requires_grad_()
  action = torch.zeros(2, 16, requires_grad=True)
  pose = torch.tensor([[1.0, 2.0, math.pi / 2], [-3.0, 5.0, -math.pi / 3]])
  total, terms = imagine._rewards(s0, s1, pose, {"velocity_command": command},
                                  action, torch.zeros_like(action), k)
  assert terms["track_lin_vel_xy"][0] == 1
  assert terms["track_ang_vel_z"][0] == 1
  assert total[0] > total[1]
  assert not any("chase" in key or "dodge" in key or "target" in key for key in terms)
  # The simulator reports velocity in world coordinates; the reward must match
  # imagined yaw-relative velocity even when the robot is turned.
  yaw = pose[:, 2]
  c, si = yaw.cos(), yaw.sin()
  vx, vy, vz = s1[:, st.V_YAW].unbind(-1)
  world_v = torch.stack([c * vx - si * vy, si * vx + c * vy, vz], -1)
  env = SimpleNamespace(
    scene={"robot": SimpleNamespace(data=SimpleNamespace(
      root_link_lin_vel_w=world_v, root_link_ang_vel_b=s1[:, st.W_B], heading_w=yaw,
    ))},
    command_manager=SimpleNamespace(get_command=lambda _: command),
  )
  for name in ("track_lin_vel_xy", "track_ang_vel_z", "lin_vel_z_l2"):
    torch.testing.assert_close(getattr(velocity_mdp, name)(env, "velocity"), terms[name])
  total.sum().backward()
  assert torch.isfinite(s1.grad).all() and torch.isfinite(action.grad).all()
  assert s1.grad[1, st.V_YAW].abs().sum() > 0
  assert s1.grad[1, st.W_B].abs().sum() > 0


def test_imagined_turn_does_not_rotate_body_relative_velocity_command():
  imagine, k, s = _imagination()
  command = torch.tensor([[0.8, -0.2, 0.7], [0.4, 0.1, -0.5]])
  context = imagine.context_state(command)
  # Replay command storage must survive without being aliased or mutated.
  assert context["velocity_command"].data_ptr() != command.data_ptr()
  actor = lambda hist: torch.zeros(hist.shape[0], 16)
  def rotating_world_model(state, action, previous, xi, relief):
    return state.clone(), torch.tensor([[0.0, 0.0, math.pi / 2]]).expand(2, -1)
  result = imagine._step(
    s, torch.zeros(2, 3), torch.zeros(2, 16), torch.zeros(2, 265), context,
    torch.zeros(2, st.CONTEXT_DIM), torch.zeros(2, 12), k, torch.full((2,), 0.02),
    actor, rotating_world_model,
  )
  _, pose, _, hist, next_context, reward, done, critic_input = result
  torch.testing.assert_close(pose[:, 2], torch.full((2,), math.pi / 2))
  assert torch.equal(next_context["velocity_command"], command)
  assert torch.equal(hist[:, -3:], command * torch.tensor(COMMAND_SCALE))
  assert critic_input.shape == (2, st.STATE_DIM + 3 + st.CONTEXT_DIM)
  assert torch.equal(critic_input[:, st.STATE_DIM:st.STATE_DIM + 3], command)
  assert torch.isfinite(reward).all() and torch.isfinite(done).all()


@pytest.mark.parametrize("task_type,task,terms", [
  ("chase", "MID80-Chase-Flat", st.OBS_TERMS),
  ("chase", "Go2-Chase-Flat", st.OBS_TERMS),
  ("velocity", VELOCITY_TASK, st.VELOCITY_OBS_TERMS),
])
def test_checkpoint_command_semantics_reject_cross_task_and_accept_own(task_type, task, terms):
  checkpoint = {"robot": st.checkpoint_robot_metadata(), "cfg": {"task": task},
                "obs_terms": terms, "history": 5}
  st.validate_checkpoint_robot(checkpoint)
  validate_checkpoint_task(checkpoint, task_type, terms, 5)
  checkpoint["task_type"] = task_type
  validate_checkpoint_task(checkpoint, task_type, terms, 5)
  other = "velocity" if task_type == "chase" else "chase"
  with pytest.raises(ValueError, match="task type"):
    validate_checkpoint_task(checkpoint, other)
  with pytest.raises(ValueError, match="history"):
    validate_checkpoint_task(checkpoint, task_type, terms, 4)
  with pytest.raises(ValueError, match="observation terms"):
    validate_checkpoint_task(checkpoint, task_type, terms[:-1], 5)
