"""Checkpoint restoration and warmup when a blind learner replaces older models."""

from copy import deepcopy
from types import SimpleNamespace

import pytest
import torch

from go2_supermimic.supermimic import state as st
from go2_supermimic.supermimic.train import Actor, Critic, Trainer, TrainCfg
from go2_supermimic.supermimic.world_model import WorldModel


def _trainer(log_dir, *, scan_dim=0, continue_run=True, reset_critic=False):
  """Exercise real save/load without constructing a simulator or GPU context."""
  trainer = Trainer.__new__(Trainer)
  trainer.cfg = TrainCfg(
    task="MID80-Velocity-Terrain" if scan_dim == 0 else "MID80-Velocity-Flat",
    device="cpu", continue_run=continue_run, reset_critic=reset_critic,
    actor_hidden=(8,), wm_hidden=(8,), critic_hidden=(8,),
  )
  trainer.dev = "cpu"
  trainer.task_type = "velocity"
  trainer.terms = st.VELOCITY_OBS_TERMS
  trainer.history = 5
  trainer.wm = WorldModel((8,), scan_dim=scan_dim)
  trainer.actor = Actor(265, (8,), 16)
  trainer.critic = Critic(81, (8,))
  trainer.opt_wm = torch.optim.Adam(trainer.wm.parameters())
  trainer.opt_actor = torch.optim.Adam(trainer.actor.parameters())
  trainer.opt_critic = torch.optim.Adam(trainer.critic.parameters())
  trainer.obs = torch.randn(2, 265)
  trainer.policy_start = trainer.cfg.warmup_iterations
  trainer.actor_frozen_until = 0
  trainer.env = SimpleNamespace(common_step_counter=0)
  trainer.start_it = 0
  trainer.log_dir = log_dir
  return trainer


def _populate_training_state(trainer):
  for name in ("wm", "actor", "critic"):
    model, optimizer = getattr(trainer, name), getattr(trainer, "opt_" + name)
    sum(parameter.square().sum() for parameter in model.parameters()).backward()
    optimizer.step()
    optimizer.zero_grad(set_to_none=True)
  for norm in (trainer.wm.in_norm, trainer.wm.out_norm, trainer.actor.norm, trainer.critic.norm):
    norm.update(torch.randn(4, norm.mean.numel()))


def test_blind_checkpoint_restores_models_normalizers_and_all_optimizer_state(tmp_path):
  source = _trainer(tmp_path)
  _populate_training_state(source)
  path = source.save(4100)
  restored = _trainer(tmp_path)

  restored.load(str(path))

  assert restored.start_it == restored.env.common_step_counter == 4100
  assert restored.policy_start == restored.cfg.warmup_iterations
  assert restored.actor_frozen_until == 0
  for name in ("wm", "actor", "critic", "opt_wm", "opt_actor", "opt_critic"):
    torch.testing.assert_close(getattr(restored, name).state_dict(),
                               getattr(source, name).state_dict(), rtol=0, atol=0)


@pytest.mark.parametrize("continue_run,start", [(True, 4100), (False, 0)])
def test_legacy_flat_world_model_gets_full_warmup_after_migration(tmp_path, continue_run, start):
  source = _trainer(tmp_path, scan_dim=77)
  _populate_training_state(source)
  path = source.save(4100)
  restored = _trainer(tmp_path, continue_run=continue_run)
  fresh_world_model = deepcopy(restored.wm.state_dict())

  restored.load(str(path))

  assert restored.start_it == restored.env.common_step_counter == start
  assert restored.policy_start == start + restored.cfg.wm_rewarmup_iterations
  assert restored.actor_frozen_until == restored.policy_start + restored.cfg.critic_warmup_iterations
  # The existing blind actor remains usable, but must wait for its new model.
  torch.testing.assert_close(restored.actor.state_dict(), source.actor.state_dict(), rtol=0, atol=0)
  torch.testing.assert_close(restored.wm.state_dict(), fresh_world_model, rtol=0, atol=0)
  assert not restored.opt_wm.state
  assert start + 1 < restored.policy_start < restored.actor_frozen_until


def test_explicit_critic_reset_warms_up_from_continued_iteration(tmp_path):
  source = _trainer(tmp_path)
  _populate_training_state(source)
  path = source.save(4100)
  restored = _trainer(tmp_path, reset_critic=True)
  fresh_critic = deepcopy(restored.critic.state_dict())

  restored.load(str(path))

  assert restored.start_it == 4100
  assert restored.policy_start == restored.cfg.warmup_iterations
  assert restored.actor_frozen_until == 4100 + restored.cfg.critic_warmup_iterations
  torch.testing.assert_close(restored.critic.state_dict(), fresh_critic, rtol=0, atol=0)
  torch.testing.assert_close(restored.wm.state_dict(), source.wm.state_dict(), rtol=0, atol=0)
  assert not restored.opt_critic.state
