"""Height sampling must not turn a corrupt pose into an invalid GPU index."""

import pytest
import torch

from go2_supermimic.target.terrain import HeightField


@pytest.fixture(params=[
  "cpu",
  pytest.param("cuda", marks=pytest.mark.skipif(
    not torch.cuda.is_available(), reason="CUDA is unavailable",
  )),
])
def device(request):
  return request.param


def test_nan_coordinates_preserve_invalid_sample_without_bad_indices(device):
  field = HeightField(torch.arange(12, device=device).reshape(3, 4).float(), (0., 0.), 1.)
  xy = torch.tensor([
    [float("nan"), 1.], [1., float("nan")],
    [float("nan"), float("nan")], [1.5, 0.5],
  ], device=device)
  heights = field.sample(xy)
  assert torch.isnan(heights[:3]).all()
  torch.testing.assert_close(heights[3], heights.new_tensor(3.5))


def test_infinite_and_outside_coordinates_keep_edge_clamping(device):
  field = HeightField(torch.arange(12, device=device).reshape(3, 4).float(), (0., 0.), 1.)
  xy = torch.tensor([
    [float("inf"), float("inf")], [-float("inf"), -float("inf")],
    [float("inf"), -float("inf")], [-float("inf"), float("inf")],
    [1e20, 1e20], [-1e20, -1e20], [0., 0.], [3., 2.],
  ], device=device)
  # The existing sampler clips just inside the upper edge (index max - .001).
  expected = xy.new_tensor([10.995, 0., 2.999, 7.996, 10.995, 0., 0., 10.995])
  torch.testing.assert_close(field.sample(xy), expected)


def test_bilinear_values_and_coordinate_gradients_are_unchanged(device):
  # z(x,y) = 2*x + 3*y + 4, sampled on a grid with a nonzero origin.
  origin, res = (-2., -3.), 0.5
  xs = torch.arange(8, device=device, dtype=torch.float64) * res + origin[0]
  ys = torch.arange(6, device=device, dtype=torch.float64) * res + origin[1]
  grid = 2. * xs[None, :] + 3. * ys[:, None] + 4.
  field = HeightField(grid, origin, res)
  xy = torch.tensor([[[-1.7, -2.6], [-0.3, -1.2]]], device=device,
                    dtype=torch.float64, requires_grad=True)
  actual = field.sample(xy)
  torch.testing.assert_close(actual, 2. * xy[..., 0] + 3. * xy[..., 1] + 4.)
  actual.sum().backward()
  torch.testing.assert_close(xy.grad, xy.new_tensor([2., 3.]).expand_as(xy))


def test_low_precision_upper_edge_never_indexes_past_grid(device):
  field = HeightField(torch.arange(64, device=device).reshape(8, 8).float(), (0., 0.), 1.)
  # float16 rounds 6.999 to 7, so an unclamped lower index would read index 8.
  xy = torch.tensor([[7., 7.]], device=device, dtype=torch.float16)
  torch.testing.assert_close(field.sample(xy), torch.tensor([63.], device=device))


@pytest.mark.parametrize("shape", [(1, 3), (3, 1), (0, 3), (3,)])
def test_grid_requires_a_bilinear_cell(shape):
  with pytest.raises(ValueError, match="at least two rows and columns"):
    HeightField(torch.zeros(shape), (0., 0.), 1.)
