"""Keep all physical terrains while training locomotion without a terrain scan."""

import math

import mujoco
import numpy as np
import pytest
import torch

from go2_supermimic.supermimic import state as st
from go2_supermimic.target import terrain as tr


@pytest.fixture(scope="module")
def terrain_model():
  from mjlab.terrains.terrain_generator import TerrainGenerator
  from go2_supermimic.env.xml_terrain import mid80_terrain_generator_cfg

  cfg = mid80_terrain_generator_cfg()
  spec = mujoco.MjSpec()
  generator = TerrainGenerator(cfg, device="cpu")
  generator.compile(spec)
  model = spec.compile()
  data = mujoco.MjData(model)
  mujoco.mj_forward(model, data)
  return model, data, generator


def _ray_heights(model, data, xy):
  heights = []
  geom_id = np.zeros(1, dtype=np.int32)
  for x, y in np.asarray(xy).reshape(-1, 2):
    distance = mujoco.mj_ray(model, data, np.array([x, y, 5.0]),
                             np.array([0.0, 0.0, -1.0]), None, 1, -1, geom_id)
    assert distance >= 0, f"missing ground at ({x}, {y})"
    heights.append(5.0 - distance)
  return np.asarray(heights)


def test_every_requested_terrain_exists_and_spawn_footprint_is_clear(terrain_model):
  from go2_supermimic.env.xml_terrain import TERRAIN_NAMES, TILE_SIZE

  expected = ("flat", "rough", *(f"stairs_{i}" for i in range(1, 6)),
              "slope", *(f"platform_{i}" for i in range(1, 6)))
  model, data, generator = terrain_model
  assert tuple(TERRAIN_NAMES) == expected
  assert tuple(generator.cfg.sub_terrains) == expected
  assert tuple(TILE_SIZE) == (8.0, 6.0)
  assert generator.terrain_origins.shape == (1, 13, 3)
  assert (model.geom_contype & 1).all() and (model.geom_conaffinity & 2).all()
  # A MID80 body plus its reset jitter fits entirely on each starting pad.
  offsets = np.array([(x, y) for x in (-0.65, 0.0, 0.65) for y in (-0.5, 0.0, 0.5)])
  for origin in generator.terrain_origins[0]:
    heights = _ray_heights(model, data, origin[:2] + offsets)
    np.testing.assert_allclose(heights, origin[2], atol=1e-6)


def test_native_rays_measure_five_stair_sizes_platform_heights_and_slope(terrain_model):
  model, data, generator = terrain_model
  names = tuple(generator.cfg.sub_terrains)
  xs = np.arange(-3.9, 3.9001, 0.002)

  def profile(name):
    y = generator.terrain_origins[0, names.index(name), 1]
    return _ray_heights(model, data, np.column_stack([xs, np.full_like(xs, y)]))

  np.testing.assert_allclose(profile("flat"), 0.0, atol=1e-6)
  rough = profile("rough")
  assert np.ptp(rough) > 0.02 and len(np.unique(np.round(rough, 5))) >= 6
  for index, (rise, tread) in enumerate(zip((.04, .06, .08, .10, .12),
                                           (.50, .45, .40, .35, .30)), start=1):
    heights = np.round(profile(f"stairs_{index}"), 6)
    levels = np.unique(heights)
    assert len(levels) >= 4, "a staircase must contain several risers"
    np.testing.assert_allclose(np.diff(levels), rise, atol=1e-5)
    # Interior plateaus expose tread depth; the floor and top landing may be longer.
    transitions = np.flatnonzero(np.diff(heights)) + 1
    starts, ends = np.r_[0, transitions], np.r_[transitions, len(xs)]
    interior = (heights[starts] > 0) & (heights[starts] < heights.max())
    widths = (ends - starts)[interior] * 0.002
    assert len(widths) >= 2
    np.testing.assert_allclose(widths, tread, atol=0.003)
  for index, height in enumerate((.08, .12, .16, .20, .24), start=1):
    np.testing.assert_allclose(np.unique(np.round(profile(f"platform_{index}"), 6)),
                               [0.0, height], atol=1e-6)
  slopes = np.diff(profile("slope")) / 0.002
  sloping = np.abs(slopes[(np.abs(slopes) > .01) & (np.abs(slopes) < .5)])
  assert len(sloping) > 200
  np.testing.assert_allclose(sloping, math.tan(math.radians(10)), atol=1e-5)


def test_standalone_xml_scene_uses_the_same_terrain_geometry_as_training(terrain_model):
  from deep_robotics_model.mid80wheeldog.generate_terrain import SCENE_PATH

  training_model, training_data, generator = terrain_model
  scene_model = mujoco.MjModel.from_xml_path(str(SCENE_PATH))
  scene_data = mujoco.MjData(scene_model)
  mujoco.mj_forward(scene_model, scene_data)
  assert (scene_model.nq, scene_model.nv) == (23, 22)
  # Avoid the robot in the centre of the preview scene while sampling every
  # terrain type; body-local XML positions must become identical world surfaces.
  points = np.array([(x, origin[1] + .317)
                     for origin in generator.terrain_origins[0] for x in (-2.123, 2.123)])
  np.testing.assert_allclose(_ray_heights(scene_model, scene_data, points),
                             _ray_heights(training_model, training_data, points), atol=1e-6)


def test_training_height_map_matches_mujoco_on_all_thirteen_tiles(terrain_model):
  from go2_supermimic.target.box_heightfield import build_box_height_field

  model, data, generator = terrain_model
  field = build_box_height_field(model, data, list(range(model.ngeom)),
                                  (-3.975, -38.975, 3.975, 38.975), .05, "cpu")
  rng = np.random.default_rng(27)
  points = []
  for origin in generator.terrain_origins[0]:
    # Query exactly on map grid points; interpolation across a vertical edge is
    # intentionally smoothed and would not be an exact native-ray comparison.
    xy = rng.integers((-75, -55), (76, 56), size=(32, 2)) * .05 + .025
    xy[:, 1] += origin[1]
    points.append(xy)
  xy = np.concatenate(points)
  physical = _ray_heights(model, data, xy)
  sampled = field.sample(torch.tensor(xy, dtype=torch.float32)).numpy()
  np.testing.assert_allclose(sampled, physical, atol=3e-5)
  assert np.ptp(sampled) > .2, "height-map queries must cover elevated terrain"


def test_velocity_terrain_task_is_blind_and_keeps_existing_tasks():
  import go2_supermimic.env  # noqa: F401
  from mjlab.tasks.registry import load_env_cfg
  from go2_supermimic.supermimic.train import TrainCfg

  terrain = load_env_cfg("MID80-Velocity-Terrain")
  flat = load_env_cfg("MID80-Velocity-Flat")
  chase = load_env_cfg("MID80-Chase-Flat")
  assert set(terrain.commands) == {"velocity"}
  assert st.obs_terms(terrain) == st.VELOCITY_OBS_TERMS
  assert sum(dim for _, dim in st.obs_terms(terrain)) * 5 == 265
  assert "height_scan" not in terrain.observations["actor"].terms
  assert sum(dim for _, dim in st.obs_terms(flat)) * 5 == 265
  assert sum(dim for _, dim in st.obs_terms(chase)) * 5 == 390
  assert terrain.observations["actor"].history_length == 5
  assert tuple(terrain.actions) == tuple(flat.actions) == ("joint_pos", "joint_vel")
  assert set(terrain.rewards) == set(flat.rewards)
  assert terrain.scene.terrain.terrain_type == "generator"
  assert len(terrain.scene.terrain.terrain_generator.sub_terrains) == 13
  assert flat.scene.terrain.terrain_type == chase.scene.terrain.terrain_type == "plane"
  assert TrainCfg().task == "MID80-Chase-Flat"
  # Registry loads must keep independent observation dictionaries.
  terrain.observations["actor"].terms.clear()
  assert st.obs_terms(load_env_cfg("MID80-Velocity-Flat")) == st.VELOCITY_OBS_TERMS


def test_terrain_imagination_never_queries_a_scan_and_has_policy_gradients(monkeypatch):
  from go2_supermimic.supermimic.imagine import ImagineCfg
  from go2_supermimic.supermimic.train import Actor, Critic
  from go2_supermimic.supermimic.velocity_imagine import VelocityImagination, VelocityRewardWeights
  from go2_supermimic.supermimic.world_model import WorldModel

  torch.manual_seed(83)
  n = 3
  consts = st.RobotConsts(
    default_q=torch.zeros(n, 12),
    action_scale=torch.tensor([[.25] * 12 + [5.0] * 4]).expand(n, -1),
    kp=torch.tensor([40.0] * 12 + [0.0] * 4),
    kd=torch.tensor([2.0] * 12 + [.6] * 4),
    effort=torch.tensor([80.0] * 12 + [90.0] * 4),
    soft_limits=torch.tensor([-1.0, 1.0]).expand(n, 12, 2),
  )
  field = tr.HeightField(torch.rand(81, 81), (-2., -2.), .05)
  imagine = VelocityImagination(
    ImagineCfg(horizon=3, weights=VelocityRewardWeights()), consts,
    history=5, device="cpu", terms=st.VELOCITY_OBS_TERMS, field=field,
  )
  actor = Actor(265, (32, 32), 16)
  critic = Critic(81, (32, 32))
  world_model = WorldModel((32, 32), scan_dim=0)
  # Keep the initial imagined trajectory close to the physical state, while
  # preserving dependence on actions for a useful BPTT gradient check.
  with torch.no_grad():
    world_model.net[-1].weight.mul_(.01)
    world_model.net[-1].bias.zero_()
  s = torch.zeros(n, st.STATE_DIM)
  s[:, st.Z] = .42
  s[:, st.GRAV] = torch.tensor([0., 0., -1.])
  command = torch.tensor([[.5, .1, .2]]).expand(n, -1)
  seed = {
    "env": torch.arange(n), "s": s, "pose": torch.randn(n, 3),
    "a_prev": torch.zeros(n, 16), "obs": torch.randn(n, 265), "gen": command,
    "xi": torch.zeros(n, st.CONTEXT_DIM), "enc_bias": torch.zeros(n, 12),
  }
  scan_shapes = []

  def reject_terrain_query(*args, **kwargs):
    pytest.fail("blind imagination queried terrain or a height scan")

  def observe_world_model_inputs(module, args):
    scan_shapes.append(tuple(args[-1].shape))

  # The field is still used for the real simulator's base-height reward. It
  # must never be queried by the actor, critic, or imagined world-model input.
  monkeypatch.setattr(tr, "relief", reject_terrain_query)
  monkeypatch.setattr(tr.HeightField, "sample", reject_terrain_query)
  monkeypatch.setattr(imagine, "scan", reject_terrain_query)
  hook = world_model.register_forward_pre_hook(observe_world_model_inputs)
  try:
    objective, data = imagine.rollout(world_model, actor, critic, seed)
  finally:
    hook.remove()
  assert not imagine.use_scan
  assert imagine.critic_dim == 81
  assert scan_shapes == [(n, 0)] * 3
  assert data["critic_in"].shape == (n, 4, 81)
  assert torch.isfinite(objective).all()
  assert all(torch.isfinite(value).all() for value in data.values())
  objective.mean().backward()
  assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in actor.parameters())
  assert sum(float(p.grad.abs().sum()) for p in actor.parameters()) > 0
  assert torch.isfinite(imagine.gae_targets(critic, data)).all()


def test_blind_replay_and_archive_train_world_model_with_no_scan_storage():
  from go2_supermimic.supermimic.buffer import ReplayBuffer, WindowArchive
  from go2_supermimic.supermimic.train import Trainer, _finite_rows
  from go2_supermimic.supermimic.world_model import WorldModel
  from types import SimpleNamespace

  torch.manual_seed(29)
  n, k, batch = 2, 2, 4
  replay = ReplayBuffer(n, 8, 265, "cpu", gen_dim=3, scan_dim=0)
  archive = WindowArchive(8, k, st.CONTEXT_DIM, "cpu", scan_dim=0)
  model = WorldModel((32, 32), scan_dim=0)
  no_scan = torch.empty(n, 0)
  assert _finite_rows(torch.ones(n, 3), no_scan).all()
  for _ in range(6):
    replay.add(torch.randn(n, st.STATE_DIM), torch.randn(n, 3),
               torch.randn(n, 16), torch.randn(n, 16), torch.randn(n, 265),
               torch.randn(n, 3), torch.zeros(n, dtype=torch.bool), no_scan)
  assert replay.relief.shape == (n, 8, 0) and replay.relief.numel() == 0
  assert archive.data["relief"].shape == (8, k, 0)
  trainer = SimpleNamespace(buf=replay, cfg=SimpleNamespace(wm_window=k),
                            xi=torch.zeros(n, st.CONTEXT_DIM))
  windows = Trainer._gather(trainer, *replay.sample_windows(batch, k))
  archive.add(windows)
  sampled = archive.sample(batch)
  assert sampled["relief"].shape == (batch, k, 0)
  assert model.in_norm.mean.shape == (110,)
  model.update_stats(sampled["s"][:, 0], sampled["a"][:, 0], sampled["a_prev"][:, 0],
                     sampled["xi"], sampled["relief"][:, 0], sampled["s"][:, 1],
                     torch.zeros(batch, 3))
  loss = model.loss(sampled["s"][:, 0], sampled["a"], sampled["a_prev"], sampled["xi"],
                    sampled["relief"], sampled["s"][:, 1:], torch.zeros(batch, k, 3),
                    sampled["valid"])
  assert torch.isfinite(loss)
  loss.backward()
  assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())


def test_blind_checkpoint_accepts_flat_policy_but_rejects_legacy_terrain_scan(tmp_path):
  from go2_supermimic.supermimic.driver import ActorDriver, validate_checkpoint_task
  from go2_supermimic.supermimic.train import Actor

  torch.manual_seed(83)
  actor = Actor(265, (32, 32), 16)
  actor.norm.mean.normal_()
  actor.norm.var.uniform_(.5, 2.)
  checkpoint = {
    "robot": st.checkpoint_robot_metadata(), "obs_dim": 265,
    "cfg": {"task": "MID80-Velocity-Flat", "actor_hidden": (32, 32)},
    "obs_terms": st.VELOCITY_OBS_TERMS, "history": 5, "actor": actor.state_dict(),
  }
  validate_checkpoint_task(checkpoint, "velocity", st.VELOCITY_OBS_TERMS, 5, allow_prefix=True)
  path = tmp_path / "blind_flat.pt"
  torch.save(checkpoint, path)
  driver = ActorDriver(str(path), 265, "cpu", "velocity", st.VELOCITY_OBS_TERMS, 5)
  obs = torch.randn(8, 265)
  with torch.no_grad():
    torch.testing.assert_close(driver.act(obs), actor(obs), atol=0, rtol=0)
  legacy = dict(checkpoint, obs_dim=650,
                 obs_terms=st.VELOCITY_OBS_TERMS + (("height_scan", tr.SCAN_POINTS),))
  with pytest.raises(ValueError, match="observation terms|height.scan|blind"):
    validate_checkpoint_task(legacy, "velocity", st.VELOCITY_OBS_TERMS, 5, allow_prefix=True)
  torch.save(legacy, path)
  with pytest.raises(ValueError, match="observation terms|height.scan|blind"):
    ActorDriver(str(path), 265, "cpu", "velocity", st.VELOCITY_OBS_TERMS, 5)
