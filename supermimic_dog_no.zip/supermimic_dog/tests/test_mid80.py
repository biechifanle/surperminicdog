"""MID80 policy/simulator boundary checks; GPU simulation is in smoke_mid80.py."""

from pathlib import Path
from types import SimpleNamespace

import pytest
import torch

from go2_supermimic.robot import constants as rc
from go2_supermimic.supermimic import state as st
from go2_supermimic.supermimic.world_model import WorldModel
from go2_supermimic.target import interface as ti
from go2_supermimic.target.terrain import SCAN_POINTS


def _fake_env():
  # MuJoCo stores a wheel after each leg, unlike the actor's legs-then-wheels order.
  names = tuple(f"{leg}_{j}_joint" for leg in ("fl", "fr", "rl", "rr")
                for j in ("abad", "hip", "knee", "wheel"))
  n = 2
  q0 = torch.arange(16, dtype=torch.float32).expand(n, -1) / 100
  data = SimpleNamespace(
    default_joint_pos=q0.clone(), joint_pos=q0 + torch.arange(16) / 10,
    joint_vel=torch.arange(16, dtype=torch.float32).expand(n, -1).clone(),
    encoder_bias=torch.arange(16, dtype=torch.float32).expand(n, -1) / 1000,
    soft_joint_pos_limits=torch.stack([q0 - 1, q0 + 1], -1),
    heading_w=torch.zeros(n), root_link_pos_w=torch.tensor([[1., 2., 0.4]]).expand(n, -1),
    root_link_lin_vel_w=torch.zeros(n, 3), root_link_ang_vel_b=torch.ones(n, 3),
    projected_gravity_b=torch.tensor([[0., 0., -1.]]).expand(n, -1),
    body_link_pos_w=torch.arange(n * 8 * 3, dtype=torch.float32).reshape(n, 8, 3) / 10,
    site_pos_w=torch.arange(n * 4 * 3, dtype=torch.float32).reshape(n, 4, 3) / 10,
  )
  actuators = [
    SimpleNamespace(target_names_expr=rc.LEG_JOINT_NAMES, stiffness=40., damping=2.,
                    effort_limit=80.),
    SimpleNamespace(target_names_expr=rc.WHEEL_JOINT_NAMES, stiffness=0., damping=1.,
                    effort_limit=20.),
  ]
  robot = SimpleNamespace(joint_names=names, data=data,
                          cfg=SimpleNamespace(articulation=SimpleNamespace(actuators=actuators)))
  body_names = rc.HIP_BODY_NAMES + rc.KNEE_BODY_NAMES
  robot.find_bodies = lambda names, preserve_order: ([body_names.index(n) for n in names], names)
  robot.find_sites = lambda names, preserve_order: ([rc.FOOT_SITE_NAMES.index(n) for n in names], names)
  terms = {
    "joint_pos": SimpleNamespace(_target_names=rc.LEG_JOINT_NAMES, _scale=rc.LEG_ACTION_SCALE),
    "joint_vel": SimpleNamespace(_target_names=rc.WHEEL_JOINT_NAMES, _scale=rc.WHEEL_ACTION_SCALE),
  }
  return SimpleNamespace(scene={"robot": robot}, num_envs=n, device="cpu",
                         action_manager=SimpleNamespace(get_term=terms.__getitem__))


def test_policy_state_maps_interleaved_urdf_joints_and_ignores_wheel_phase():
  env = _fake_env()
  robot = env.scene["robot"]
  ids = [robot.joint_names.index(name) for name in rc.JOINT_NAMES]
  s = st.robot_state(env)
  assert s.shape == (2, 74)
  assert torch.allclose(s[:, st.Q], (robot.data.joint_pos - robot.data.default_joint_pos)[:, ids[:12]])
  assert torch.equal(s[:, st.QD], robot.data.joint_vel[:, ids])
  assert torch.equal(st.leg_encoder_bias(robot), robot.data.encoder_bias[:, ids[:12]])
  # Full revolutions cannot change a wheel robot's policy input or model state.
  robot.data.joint_pos[:, ids[12:]] += 400 * torch.pi
  assert torch.equal(st.robot_state(env), s)
  limbs = st.limb_points_world(s, st.planar_pose(env))
  assert torch.allclose(limbs["feet"], robot.data.site_pos_w)


def test_robot_constants_follow_policy_order_and_separate_position_velocity_scales():
  env = _fake_env()
  consts = st.robot_consts(env)
  ids = st.policy_joint_ids(env.scene["robot"])
  assert torch.equal(consts.default_q, env.scene["robot"].data.default_joint_pos[:, ids[:12]])
  assert consts.soft_limits.shape == (2, 12, 2)
  assert consts.action_scale.shape == (2, 16)
  assert torch.equal(consts.action_scale[:, :12], torch.full((2, 12), 0.25))
  assert torch.equal(consts.action_scale[:, 12:], torch.full((2, 4), 5.0))
  assert (consts.kp[12:] == 0).all() and (consts.kd[12:] > 0).all()
  env.action_manager.get_term("joint_vel")._target_names = rc.WHEEL_JOINT_NAMES[::-1]
  with pytest.raises(ValueError, match="action order"):
    st.robot_consts(env)


def test_observations_scale_joint_velocity_and_preserve_term_history():
  torch.manual_seed(0)
  env = _fake_env()
  s = st.robot_state(env)
  action = torch.randn(2, 16)
  target = torch.randn(2, ti.DIM)
  bias = st.leg_encoder_bias(env.scene["robot"])
  frame = st.obs_frame(s, action, target, bias, noise=False)
  assert torch.allclose(frame["joint_pos"], s[:, st.Q] + bias)
  assert torch.allclose(frame["joint_vel"], s[:, st.QD] * 0.05)
  assert torch.equal(frame["actions"], action)
  assert sum(dim for _, dim in st.OBS_TERMS) * 5 == 390
  hist = torch.randn(2, 390)
  advanced = st.push_history(hist, frame, 5)
  offset = 0
  for name, dim in st.OBS_TERMS:
    old = hist[:, offset:offset + 5 * dim]
    new = advanced[:, offset:offset + 5 * dim]
    assert torch.equal(new[:, :-dim], old[:, dim:])
    assert torch.equal(new[:, -dim:], frame[name])
    offset += 5 * dim
  noisy = st.obs_frame(s, action, target, bias, noise=True)
  assert (noisy["joint_vel"] - frame["joint_vel"]).abs().max() <= 1.5 * 0.05 + 1e-6


def test_wheel_velocity_command_produces_torque_with_zero_position_gain():
  from go2_supermimic.supermimic.imagine import joint_torques

  env = _fake_env()
  c = st.robot_consts(env)
  s = torch.zeros(2, st.STATE_DIM)
  a = torch.zeros(2, 16, requires_grad=True)
  with torch.no_grad():
    a[:, 12:] = torch.tensor([1., -1., 100., -100.])
    s[:, st.QD][:, 12:] = torch.tensor([2., -2., 0., 0.])
  k = {"default_q": c.default_q, "action_scale": c.action_scale}
  tau = joint_torques(s, a, k, c)
  assert tau.shape == (2, 16)
  assert torch.equal(tau[:, :12], torch.zeros(2, 12))
  assert torch.allclose(tau[:, 12:], torch.tensor([[3., -3., 20., -20.]]).expand(2, -1))
  tau[:, 12:14].square().sum().backward()
  assert torch.isfinite(a.grad).all() and (a.grad[:, 12:14].abs() > 0).all()


def test_world_model_trains_with_16_actions_and_74_state_values():
  torch.manual_seed(0)
  model = WorldModel((32, 32))
  n, k = 4, 2
  s = torch.randn(n, st.STATE_DIM)
  actions = torch.randn(n, k, st.NUM_JOINTS)
  xi = torch.randn(n, st.CONTEXT_DIM)
  relief = torch.zeros(n, k, SCAN_POINTS)
  targets = s[:, None].expand(-1, k, -1) + 0.01
  loss = model.loss(s, actions, torch.zeros_like(actions), xi, relief, targets,
                    torch.zeros(n, k, 3), torch.ones(n, k))
  optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
  before = model.net[0].weight.detach().clone()
  loss.backward()
  assert torch.isfinite(loss)
  assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())
  optimizer.step()
  assert not torch.equal(before, model.net[0].weight)


def test_go2_checkpoints_are_rejected_before_loading_network_weights():
  with pytest.raises(ValueError, match="not compatible with MID80"):
    st.validate_checkpoint_robot({"obs_dim": 350})
  st.validate_checkpoint_robot({"robot": st.checkpoint_robot_metadata()})


def test_mid80_xml_compiles_with_four_continuous_wheels():
  mujoco = pytest.importorskip("mujoco")
  path = Path(__file__).resolve().parents[1] / "deep_robotics_model/mid80wheeldog/mjcf/mid80.xml"
  model = mujoco.MjModel.from_xml_path(str(path))
  assert model.nq == 23 and model.nv == 22
  for name in rc.JOINT_NAMES:
    assert model.joint(name).id >= 0
  for name in rc.WHEEL_JOINT_NAMES:
    assert not model.jnt_limited[model.joint(name).id]
  for name in rc.FOOT_SITE_NAMES:
    assert model.site(name).id >= 0
  for name in rc.FOOT_GEOM_NAMES:
    assert model.geom(name).size[0] == pytest.approx(rc.WHEEL_RADIUS)
  assert model.body(rc.BASE_BODY_NAME).mass[0] > 0
