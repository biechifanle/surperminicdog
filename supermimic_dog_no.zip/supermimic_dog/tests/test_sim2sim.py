"""Native MuJoCo deployment matches the MID80 training policy boundary."""

import math

import mujoco
import numpy as np
import pytest
import torch

from deep_robotics_model.mid80wheeldog.generate_terrain import TERRAIN_NAMES
from go2_supermimic.robot import constants as rc
from go2_supermimic.supermimic import state as st
from go2_supermimic.supermimic.train import Actor as TrainingActor
from scripts import sim2sim


TERMS = st.VELOCITY_OBS_TERMS


@pytest.fixture(scope="module")
def native_sim():
    return sim2sim.NativeSim(terrain="flat", seed=80, delay_steps=0)


@pytest.fixture
def sim(native_sim):
    native_sim.reset("flat")
    return native_sim


def _assert_repeated_history(sim, frame):
    offset = 0
    for name, dim in TERMS:
        term_history = sim.history[:, offset:offset + 5 * dim].reshape(1, 5, dim)
        torch.testing.assert_close(term_history, frame[name][:, None, :].expand(-1, 5, -1))
        offset += 5 * dim
    assert offset == 265


def test_initial_history_and_reset_clear_previous_episode(sim):
    assert sim.history.shape == (1, 265)
    assert not hasattr(sim, "field")
    _assert_repeated_history(sim, sim.observe(np.zeros(3)))
    sim.history.fill_(123.0)
    sim.last_action[:] = 4.0
    sim.step(np.full(16, 0.1))
    assert sim.data.time > 0
    sim.reset("stairs_3")
    assert sim.terrain == "stairs_3"
    assert sim.data.time == 0
    np.testing.assert_array_equal(sim.last_action, np.zeros(16))
    np.testing.assert_allclose(sim.data.qvel, 0)
    _assert_repeated_history(sim, sim.observe(np.zeros(3)))


def test_native_observations_match_training_at_rotated_nonzero_state(sim):
    sim.reset("stairs_3")
    # Put the robot over a real step and rotate all three axes. Distinct values
    # in every joint catch confusing URDF-interleaved and policy joint orders.
    sim.data.qpos[0] = 1.15
    sim.data.qpos[2] = 0.9
    roll, pitch, yaw = 0.23, -0.17, 0.61
    cr, sr = math.cos(roll / 2), math.sin(roll / 2)
    cp, sp = math.cos(pitch / 2), math.sin(pitch / 2)
    cy, sy = math.cos(yaw / 2), math.sin(yaw / 2)
    sim.data.qpos[3:7] = [cr * cp * cy + sr * sp * sy,
                          sr * cp * cy - cr * sp * sy,
                          cr * sp * cy + sr * cp * sy,
                          cr * cp * sy - sr * sp * cy]
    q = np.linspace(-0.16, 0.17, 16)
    q[12:] = [13.0, -17.0, 21.0, -25.0]
    qd = np.linspace(-3.7, 4.1, 16)
    sim.data.qpos[sim.qids] = q
    sim.data.qvel[sim.vids] = qd
    sim.data.qvel[3:6] = [0.31, -0.42, 0.57]
    sim.last_action[:] = np.linspace(-0.5, 0.8, 16)
    mujoco.mj_forward(sim.model, sim.data)
    command = np.array([0.6, -0.2, 0.4])
    frame = sim.observe(command)

    ids = np.array([sim.model.joint(name).id for name in rc.JOINT_NAMES])
    np.testing.assert_array_equal(sim.qids, sim.model.jnt_qposadr[ids])
    np.testing.assert_array_equal(sim.vids, sim.model.jnt_dofadr[ids])
    base = sim.model.body(rc.BASE_BODY_NAME).id
    rotation = sim.data.xmat[base].reshape(3, 3)
    velocity = np.zeros(6)
    # mjOBJ_BODY with flg_local=1 uses the body's inertial frame, which is
    # rotated relative to the MID80 link frame. Rotate world angular velocity
    # into the link frame explicitly; the IMU site is aligned with that frame.
    mujoco.mj_objectVelocity(sim.model, sim.data, mujoco.mjtObj.mjOBJ_BODY,
                            base, velocity, 0)
    angular_velocity = rotation.T @ velocity[:3]
    np.testing.assert_allclose(angular_velocity, sim.data.qvel[3:6], atol=1e-12)
    gravity = rotation.T @ np.array([0.0, 0.0, -1.0])
    measured_yaw = math.atan2(rotation[1, 0], rotation[0, 0])
    np.testing.assert_allclose(measured_yaw, yaw, atol=1e-12)

    state = torch.zeros(1, st.STATE_DIM)
    state[:, st.GRAV] = torch.tensor(gravity, dtype=torch.float32)
    state[:, st.W_B] = torch.tensor(angular_velocity, dtype=torch.float32)
    state[:, st.Q] = torch.tensor(q[:12], dtype=torch.float32)
    state[:, st.QD] = torch.tensor(qd, dtype=torch.float32)
    reference = st.obs_frame(
        state, torch.tensor(sim.last_action[None], dtype=torch.float32), None,
        torch.zeros(1, 12), noise=False,
        velocity_command=torch.tensor(command[None], dtype=torch.float32),
    )
    assert tuple(frame) == tuple(name for name, _ in TERMS)
    for name, dim in TERMS:
        assert frame[name].shape == (1, dim)
        torch.testing.assert_close(frame[name], reference[name], atol=2e-5, rtol=2e-5,
                                   msg=f"Native/training observation mismatch: {name}")


def test_blind_observation_does_not_depend_on_world_position_or_tile(sim):
    command = np.array([0.5, -0.1, 0.3])
    reference = sim.observe(command)
    # The policy sees neither terrain geometry nor absolute position/height.
    for tile in TERRAIN_NAMES:
        sim.reset(tile)
        sim.data.qpos[:3] += [1.3, 0.2, 0.4]
        mujoco.mj_forward(sim.model, sim.data)
        frame = sim.observe(command)
        assert "height_scan" not in frame
        for name, _ in TERMS:
            torch.testing.assert_close(frame[name], reference[name])


def test_pd_torque_uses_wheel_velocity_and_only_clips_effort():
    action = np.array([4.0, -4.0, *([0.4] * 10), 0.7, -0.8, 100.0, -100.0])
    q = np.linspace(-0.2, 0.2, 16)
    qd = np.linspace(-0.4, 0.4, 16)
    expected = np.concatenate((40 * (0.25 * action[:12] - q[:12]) - 2 * qd[:12],
                               0.6 * (5 * action[12:] - qd[12:])))
    limits = np.array([80.0] * 12 + [90.0] * 4)
    expected = np.clip(expected, -limits, limits)
    np.testing.assert_allclose(sim2sim.pd_torques(action, q, qd), expected)
    # An action >1 is valid, whereas only torques saturate. Wheel position is
    # continuous and must never feed a position controller.
    assert expected[0] > 40
    assert expected[-2] == 90 and expected[-1] == -90
    q[12:] += 1000
    np.testing.assert_allclose(sim2sim.pd_torques(action, q, qd), expected)


def test_scene_uses_training_actuators_and_physics(sim):
    model = sim.model
    assert (model.nq, model.nv, model.nu) == (23, 22, 16)
    assert model.opt.timestep == pytest.approx(0.005)
    assert model.opt.integrator == mujoco.mjtIntegrator.mjINT_IMPLICITFAST
    assert model.opt.solver == mujoco.mjtSolver.mjSOL_NEWTON
    assert model.opt.cone == mujoco.mjtCone.mjCONE_ELLIPTIC
    assert model.opt.impratio == 10
    assert model.opt.iterations == 10 and model.opt.ls_iterations == 20
    assert model.opt.ccd_iterations == 50
    np.testing.assert_allclose(model.dof_armature[sim.vids], [0.01] * 12 + [0.00243216] * 4)
    np.testing.assert_allclose(model.dof_frictionloss[sim.vids], 0)
    for name in rc.FOOT_GEOM_NAMES:
        geom = model.geom(name).id
        assert model.geom_condim[geom] == 6 and model.geom_priority[geom] == 1
        assert model.geom_contype[geom] == 2 and model.geom_conaffinity[geom] == 1
        np.testing.assert_allclose(model.geom_friction[geom], [1, 0.005, 0.0005])
        np.testing.assert_allclose(model.geom_solref[geom], [0.01, 1])
    for i, name in enumerate(rc.JOINT_NAMES):
        joint = model.joint(name).id
        actuator_ids = np.flatnonzero(model.actuator_trnid[:, 0] == joint)
        assert actuator_ids.size == 1
        aid = actuator_ids[0]
        limit = 80 if i < 12 else 90
        np.testing.assert_allclose(model.actuator_ctrlrange[aid], [-limit, limit])
        np.testing.assert_allclose(model.actuator_forcerange[aid], [-limit, limit])
        assert model.actuator_ctrllimited[aid] and model.actuator_forcelimited[aid]


def test_all_thirteen_terrain_resets_step_and_refresh_sensors(sim):
    assert len(TERRAIN_NAMES) == 13
    action = np.array([0.0] * 12 + [0.1] * 4)
    for name in TERRAIN_NAMES:
        sim.reset(name)
        for _ in range(3):
            sim.step(action)
        assert sim.terrain == name
        assert sim.data.time == pytest.approx(0.06)
        assert np.isfinite(sim.data.qpos).all() and np.isfinite(sim.data.qvel).all()
        assert sim.data.qpos[2] > 0.2
        np.testing.assert_array_equal(sim.last_action, action)
        frame_before = sim.observe(np.zeros(3))
        mujoco.mj_forward(sim.model, sim.data)
        frame_after = sim.observe(np.zeros(3))
        for term, _ in TERMS:
            assert torch.isfinite(frame_before[term]).all()
            torch.testing.assert_close(frame_before[term], frame_after[term], atol=1e-6, rtol=1e-6)


@pytest.fixture
def trained_checkpoint():
    torch.manual_seed(80)
    actor = TrainingActor(265, (32, 24), 16).eval()
    actor.norm.mean.copy_(torch.linspace(-0.3, 0.3, 265))
    actor.norm.var.copy_(torch.linspace(0.5, 1.5, 265))
    actor.norm.count.fill_(123)
    checkpoint = {"actor": actor.state_dict(), "obs_dim": 265,
                  "cfg": {"task": "MID80-Velocity-Terrain", "actor_hidden": (32, 24)},
                  "task_type": "velocity", "history": 5, "obs_terms": TERMS,
                  "robot": st.checkpoint_robot_metadata()}
    return actor, checkpoint


def test_load_policy_matches_training_actor_and_normalization(tmp_path, trained_checkpoint):
    expected, checkpoint = trained_checkpoint
    path = tmp_path / "model.pt"
    torch.save(checkpoint, path)
    actual = sim2sim.load_policy(path)
    assert not actual.training
    obs = torch.randn(4, 265)
    obs[0, :20] *= 100  # Also exercise RunningNorm's normalized ±10 clamp.
    with torch.inference_mode():
        torch.testing.assert_close(actual(obs), expected(obs), atol=1e-6, rtol=1e-6)


@pytest.mark.parametrize("wrong", ["chase", "scan", "history", "joint_order", "term_order"])
def test_load_policy_rejects_incompatible_semantics(tmp_path, trained_checkpoint, wrong):
    _, checkpoint = trained_checkpoint
    if wrong == "chase":
        checkpoint["task_type"] = "chase"
    elif wrong == "scan":
        checkpoint["obs_dim"] = 650
        checkpoint["obs_terms"] = TERMS + (("height_scan", 77),)
        checkpoint["actor"] = TrainingActor(650, (32, 24), 16).state_dict()
    elif wrong == "history":
        checkpoint["history"] = 4
    elif wrong == "joint_order":
        checkpoint["robot"]["joint_names"] = list(reversed(rc.JOINT_NAMES))
    elif wrong == "term_order":
        checkpoint["obs_terms"] = tuple(reversed(TERMS))
    path = tmp_path / "incompatible.pt"
    torch.save(checkpoint, path)
    with pytest.raises(ValueError):
        sim2sim.load_policy(path)


def test_load_legacy_scan_policy_without_terms_has_retraining_message(tmp_path, trained_checkpoint):
    _, checkpoint = trained_checkpoint
    checkpoint.pop("obs_terms")
    checkpoint["obs_dim"] = 650
    path = tmp_path / "legacy_scan.pt"
    torch.save(checkpoint, path)
    with pytest.raises(ValueError, match="Retrain MID80-Velocity-Terrain"):
        sim2sim.load_policy(path)


def test_load_blind_flat_policy_with_legacy_metadata(tmp_path, trained_checkpoint):
    expected, checkpoint = trained_checkpoint
    checkpoint["cfg"]["task"] = "MID80-Velocity-Flat"
    for key in ("task_type", "obs_terms", "history"):
        checkpoint.pop(key)
    path = tmp_path / "blind_flat.pt"
    torch.save(checkpoint, path)
    actual = sim2sim.load_policy(path)
    obs = torch.randn(4, 265)
    with torch.inference_mode():
        torch.testing.assert_close(actual(obs), expected(obs))


def test_policy_step_advances_term_history_with_previous_raw_action(sim):
    previous = np.linspace(-0.05, 0.05, 16)
    sim.step(previous)
    command = np.array([0.4, -0.1, 0.3])
    before = sim.history.clone()
    frame = sim.observe(command)
    expected = st.push_history(before, frame, 5, TERMS)
    output = torch.tensor([[0.0] * 12 + [0.1] * 4])

    class RecordingActor(torch.nn.Module):
        def forward(self, obs):
            torch.testing.assert_close(obs, expected)
            return output

    sim.policy_step(RecordingActor(), command)
    torch.testing.assert_close(sim.history, expected)
    np.testing.assert_allclose(sim.last_action, output.numpy()[0])
    assert sim.data.time == pytest.approx(0.04)
