"""Exercise joystick bytes and command safety without a physical controller."""

import importlib.util
import math
import os
from pathlib import Path
import struct

import numpy as np
import pytest


_SPEC = importlib.util.spec_from_file_location(
    "sim2sim_gamepad_tests", Path(__file__).resolve().parents[1] / "scripts/sim2sim.py",
)
sim2sim = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(sim2sim)
Gamepad, ControlState = sim2sim.Gamepad, sim2sim.ControlState


def event(value, kind, number):
    return struct.pack("=IhBB", 0, value, kind, number)


@pytest.fixture
def pipe_gamepad():
    opened = []

    def make(**kwargs):
        reader, writer = os.pipe2(os.O_NONBLOCK)
        gamepad = Gamepad(**kwargs)
        gamepad.fd = reader
        opened.append((gamepad, writer))
        return gamepad, writer

    yield make
    for gamepad, writer in opened:
        gamepad.close()
        try:
            os.close(writer)
        except OSError:
            pass


def snapshot(*pressed, axes=(1.0, 1.0, 1.0), connected=True):
    return {"connected": connected, "axes": np.asarray(axes), "pressed": set(pressed)}


def test_initial_events_update_state_without_enabling(pipe_gamepad):
    gamepad, writer = pipe_gamepad()
    os.write(writer, event(-32768, 0x82, 1) + event(32767, 0x82, 0)
             + event(-32768, 0x82, 3) + event(1, 0x81, 0))
    current = gamepad.poll()
    assert current["connected"]
    np.testing.assert_array_equal(current["axes"], (1, -1, 1))
    assert current["raw_buttons"] == {0: True}
    assert current["pressed"] == set()
    # A held button reported during connection must be released and pressed
    # before it can enable movement.
    os.write(writer, event(1, 0x01, 0))
    assert gamepad.poll()["pressed"] == set()


def test_only_button_rising_edges_emit_actions(pipe_gamepad):
    gamepad, writer = pipe_gamepad()
    os.write(writer, event(1, 0x01, 0) + event(1, 0x01, 5))
    assert gamepad.poll()["pressed"] == {"enable", "next"}
    assert gamepad.poll()["pressed"] == set()
    os.write(writer, event(1, 0x01, 0))
    assert gamepad.poll()["pressed"] == set()
    os.write(writer, event(0, 0x01, 0))
    assert gamepad.poll()["pressed"] == set()
    os.write(writer, event(1, 0x01, 0))
    assert gamepad.poll()["pressed"] == {"enable"}


def test_short_reads_preserve_partial_event(pipe_gamepad):
    gamepad, writer = pipe_gamepad()
    packed = event(32767, 0x02, 3)
    os.write(writer, packed[:3])
    assert gamepad.poll()["raw_axes"] == {}
    os.write(writer, packed[3:7])
    assert gamepad.poll()["raw_axes"] == {}
    os.write(writer, packed[7:])
    current = gamepad.poll()
    np.testing.assert_array_equal(current["axes"], (0, 0, -1))
    # EAGAIN preserves the last known values and does not disconnect.
    again = gamepad.poll()
    assert again["connected"]
    np.testing.assert_array_equal(again["axes"], current["axes"])


def test_deadzone_axis_remapping_and_directions(pipe_gamepad):
    gamepad, writer = pipe_gamepad(axes=(2, 5, 7), signs=(1, -1, 1), deadzone=0.125)
    os.write(writer, event(-4096, 0x02, 2) + event(-16384, 0x02, 5)
             + event(32767, 0x02, 7))
    current = gamepad.poll()
    np.testing.assert_allclose(current["axes"], (0, (0.5 - 0.125) / 0.875, 1))
    assert current["raw_axes"][2] == -0.125
    assert current["raw_axes"][5] == -0.5


def test_disconnect_drops_queued_enable_and_all_axis_state(pipe_gamepad):
    gamepad, writer = pipe_gamepad()
    os.write(writer, event(-32768, 0x02, 1))
    assert gamepad.poll()["axes"][0] == 1
    os.write(writer, event(1, 0x01, 0))
    os.close(writer)
    current = gamepad.poll()
    assert not current["connected"]
    assert gamepad.fd is None
    np.testing.assert_array_equal(current["axes"], (0, 0, 0))
    assert current["raw_axes"] == current["raw_buttons"] == {}
    assert current["pressed"] == set()


def test_reconnect_clears_old_buttons_and_requires_a_new_press(pipe_gamepad, monkeypatch):
    gamepad, writer = pipe_gamepad()
    os.write(writer, event(1, 0x01, 0) + event(-32768, 0x02, 1))
    assert gamepad.poll()["pressed"] == {"enable"}
    os.close(writer)
    assert not gamepad.poll()["connected"]
    reader, writer2 = os.pipe2(os.O_NONBLOCK)
    try:
        monkeypatch.setattr(sim2sim.os, "open", lambda *_: reader)
        gamepad._next_connect = 0
        os.write(writer2, event(1, 0x81, 0))
        current = gamepad.poll()
        assert current["connected"]
        np.testing.assert_array_equal(current["axes"], (0, 0, 0))
        assert current["pressed"] == set()
        os.write(writer2, event(0, 0x01, 0) + event(1, 0x01, 0))
        assert gamepad.poll()["pressed"] == {"enable"}
    finally:
        os.close(writer2)


def test_control_starts_disarmed_and_smooths_only_after_enable():
    controls = ControlState()
    command, _ = controls.update(snapshot())
    np.testing.assert_array_equal(command, (0, 0, 0))
    assert not controls.armed
    command, events = controls.update(snapshot("enable"), dt=0.02)
    assert controls.armed and events == {"enable"}
    assert 0 < command[0] < 1
    np.testing.assert_allclose(command, np.array((1, 0.3, 1)) * (1 - math.exp(-0.02 / 0.15)))
    # Returned arrays must not permit consumers to corrupt filter state.
    command.fill(100)
    assert (controls.command <= 1).all()


def test_control_speed_limits_and_backward_limit():
    controls = ControlState(tau=0)
    command, _ = controls.update(snapshot("enable", axes=(2, -2, 2)))
    np.testing.assert_array_equal(command, (1, -0.3, 1))
    command, _ = controls.update(snapshot(axes=(-2, 2, -2)))
    np.testing.assert_array_equal(command, (-0.5, 0.3, -1))


@pytest.mark.parametrize("action", ("stop", "reset", "next", "prev", "quit"))
def test_stop_and_reset_actions_override_enable_and_clear_filter_immediately(action):
    controls = ControlState()
    before, _ = controls.update(snapshot("enable"))
    assert before[0] > 0
    command, events = controls.update(snapshot("enable", action))
    assert events == {"enable", action}
    assert not controls.armed
    np.testing.assert_array_equal(command, (0, 0, 0))
    command, _ = controls.update(snapshot())
    np.testing.assert_array_equal(command, (0, 0, 0))


def test_disconnect_overrides_enable_and_reconnection_does_not_rearm():
    controls = ControlState(tau=0)
    assert controls.update(snapshot("enable"))[0][0] == 1
    command, _ = controls.update(snapshot("enable", connected=False))
    assert not controls.armed
    np.testing.assert_array_equal(command, (0, 0, 0))
    command, _ = controls.update(snapshot(connected=True))
    assert not controls.armed
    np.testing.assert_array_equal(command, (0, 0, 0))
    command, _ = controls.update(snapshot("enable"))
    assert controls.armed
    np.testing.assert_array_equal(command, (1, 0.3, 1))
