"""MID80 policy ordering and scales, independent of the simulator.

The URDF interleaves each wheel with its leg. Policy tensors instead use the
reference mid80_wheel_env_cfg.py order: all 12 leg joints, then all four wheels.
"""

POLICY_LEGS = ("fl", "fr", "rl", "rr")
LEG_JOINT_NAMES = tuple(
  f"{leg}_{joint}_joint" for leg in POLICY_LEGS for joint in ("abad", "hip", "knee")
)
WHEEL_JOINT_NAMES = tuple(f"{leg}_wheel_joint" for leg in POLICY_LEGS)
JOINT_NAMES = LEG_JOINT_NAMES + WHEEL_JOINT_NAMES

# Keep the existing target geometry's FR, FL, RR, RL limb order.
LIMB_LEGS = ("fr", "fl", "rr", "rl")
BASE_BODY_NAME = "base_link"
HIP_BODY_NAMES = tuple(f"{leg}_hip_Link" for leg in LIMB_LEGS)
KNEE_BODY_NAMES = tuple(f"{leg}_knee_Link" for leg in LIMB_LEGS)
FOOT_SITE_NAMES = tuple(leg.upper() for leg in LIMB_LEGS)
FOOT_GEOM_NAMES = tuple(f"{leg}_wheel_collision" for leg in LIMB_LEGS)
WHEEL_RADIUS = 0.079
# Robot-specific geometry shared by actual and imagined collision/reward paths.
# Trunk bounds come from base_link.STL in the URDF frame.
TRUNK_X = (-0.38782379, 0.38782379)
TRUNK_Y = (-0.111, 0.11135)
TRUNK_BELOW_BASE = 0.08
TRUNK_ABOVE_BASE = 0.08
HEAD_OFFSET = 0.388  # Matches the MJCF head site.
# Nominal all-zero joint pose with the wheel bottoms touching level ground.
STAND_HEIGHT = 0.16971 + 0.16971 + WHEEL_RADIUS
# Keep the original 8 mm clearance above the contact surface for lift shaping
# (the Go2 site baseline was 0.030 m with a 0.022 m foot radius).
WHEEL_LIFT_BASELINE = WHEEL_RADIUS + 0.008
LEG_ACTION_SCALE = 0.25
WHEEL_ACTION_SCALE = 5.0
JOINT_VEL_OBS_SCALE = 0.05
