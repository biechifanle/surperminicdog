"""MID80 wheel-legged robot using its URDF-derived MJCF.

Gains, effort limits, armature and command delay follow MID80_WHEEL_CFG in the
companion Isaac Lab project. Ideal PD matches its DelayedPDActuator control law;
no unmeasured motor torque-speed curve is introduced.
"""

from pathlib import Path

import mujoco

from mjlab.actuator import IdealPdActuatorCfg
from mjlab.entity import EntityArticulationInfoCfg, EntityCfg
from mjlab.utils.spec_config import CollisionCfg

from go2_supermimic.robot.constants import LEG_JOINT_NAMES, WHEEL_JOINT_NAMES

MID80_XML = (
  Path(__file__).resolve().parents[2]
  / "deep_robotics_model" / "mid80wheeldog" / "mjcf" / "mid80.xml"
)


def get_spec() -> mujoco.MjSpec:
  return mujoco.MjSpec.from_file(str(MID80_XML))


def get_mid80_robot_cfg() -> EntityCfg:
  """A fresh configuration with 12 leg PD motors and four wheel speed motors."""
  return EntityCfg(
    spec_fn=get_spec,
    init_state=EntityCfg.InitialStateCfg(
      # Zero-angle wheel bottoms are 0.41842 m below the base in this URDF.
      pos=(0.0, 0.0, 0.42),
      joint_pos={".*": 0.0},
      joint_vel={".*": 0.0},
    ),
    articulation=EntityArticulationInfoCfg(
      actuators=(
        IdealPdActuatorCfg(
          target_names_expr=LEG_JOINT_NAMES,
          stiffness=40.0, damping=2.0, effort_limit=80.0,
          armature=0.01, frictionloss=0.0, delay_max_lag=2,
        ),
        IdealPdActuatorCfg(
          target_names_expr=WHEEL_JOINT_NAMES,
          stiffness=0.0, damping=0.6, effort_limit=90.0,
          armature=0.00243216, frictionloss=0.0, delay_max_lag=2,
        ),
      ),
      soft_joint_pos_limit_factor=0.9,
    ),
    collisions=(CollisionCfg(
      geom_names_expr=(r".*_collision",),
      # Reference asset disables self collision; terrain uses mask 1.
      contype=2, conaffinity=1, solref=(0.01, 1),
      condim={r".*_wheel_collision": 6, r".*_collision": 1},
      priority={r".*_wheel_collision": 1, ".*": 0},
      friction={r".*_wheel_collision": (1.0, 5e-3, 5e-4)},
    ),),
  )
