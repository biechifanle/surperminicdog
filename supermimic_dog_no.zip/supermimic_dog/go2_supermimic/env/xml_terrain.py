"""Use the authored MID80 terrain XML as mjlab's physical terrain source."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import xml.etree.ElementTree as ET

import mujoco
import numpy as np

from mjlab.terrains.terrain_generator import (
    SubTerrainCfg, TerrainGeneratorCfg, TerrainGeometry, TerrainOutput,
)
from deep_robotics_model.mid80wheeldog.generate_terrain import (
    PLATFORM_HEIGHTS, SLOPE_DEGREES, SPAWN_ORIGIN, STAIR_HEIGHTS, STAIR_WIDTHS,
    TERRAIN_NAMES, TILE_SIZE, XML_PATH,
)


def _floats(element: ET.Element, key: str, default: str):
    return tuple(float(value) for value in element.get(key, default).split())


@dataclass
class XmlTerrainCfg(SubTerrainCfg):
    """One named XML tile, with a flat reset pad in its centre.

    XML body positions describe the standalone preview layout. The training
    generator places each tile itself, so only local geometry positions are read.
    """

    terrain_name: str = "flat"
    xml_path: Path = XML_PATH

    def function(self, difficulty, spec: mujoco.MjSpec, rng) -> TerrainOutput:
        del difficulty, rng  # Each named tile has fixed, documented dimensions.
        if tuple(self.size) != TILE_SIZE:
            raise ValueError(f"MID80 XML tiles require size={TILE_SIZE}, got {self.size}")
        root = ET.parse(self.xml_path).getroot()
        source = root.find(f"worldbody/body[@name='{self.terrain_name}']")
        if source is None:
            raise ValueError(f"Unknown MID80 terrain {self.terrain_name!r} in {self.xml_path}")
        terrain_body = spec.body("terrain")
        geometries = []
        for element in source.findall("geom"):
            if element.get("type") != "box":
                raise ValueError(f"Unsupported XML terrain geom: {element.attrib}")
            color = _floats(element, "rgba", "0.6 0.6 0.6 1")
            geom = terrain_body.add_geom(
                name=f"{element.attrib['name']}_{len(terrain_body.geoms)}",
                type=mujoco.mjtGeom.mjGEOM_BOX,
                pos=_floats(element, "pos", "0 0 0"),
                size=_floats(element, "size", "1 1 1"),
                quat=_floats(element, "quat", "1 0 0 0"),
                rgba=color,
                contype=int(element.get("contype", "1")),
                conaffinity=int(element.get("conaffinity", "2")),
                condim=int(element.get("condim", "3")),
                friction=_floats(element, "friction", "1 0.005 0.0001"),
                group=int(element.get("group", "0")), mass=0.0,
            )
            geometries.append(TerrainGeometry(geom=geom, color=color))
        return TerrainOutput(origin=np.asarray(SPAWN_ORIGIN), geometries=geometries)


def mid80_terrain_generator_cfg() -> TerrainGeneratorCfg:
    """A fresh deterministic grid: all 13 terrain types are always present."""
    return TerrainGeneratorCfg(
        seed=80, curriculum=True, size=TILE_SIZE,
        num_rows=1, num_cols=len(TERRAIN_NAMES), border_width=0.0,
        color_scheme="height", add_lights=False,
        sub_terrains={
            name: XmlTerrainCfg(terrain_name=name, size=TILE_SIZE)
            for name in TERRAIN_NAMES
        },
    )
