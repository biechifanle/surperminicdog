"""Register chase/dodge and basic velocity tasks with mjlab on import."""

from mjlab.rl import RslRlOnPolicyRunnerCfg
from mjlab.tasks.registry import register_mjlab_task

from go2_supermimic.env.env_cfg import mid80_chase_env_cfg
from go2_supermimic.env.velocity_env_cfg import mid80_velocity_env_cfg, mid80_velocity_terrain_env_cfg
from go2_supermimic.locomotion import VELOCITY_TASK

for task_id, kw in (
  ("MID80-Chase-Flat", {}),
  ("MID80-Chase-Obstacles", {"obstacles": True}),
  ("MID80-Chase-Terrain", {"terrain": True}),
  # Compatibility aliases for existing launch commands; these also use MID80.
  ("Go2-Chase-Flat", {}),
  ("Go2-Chase-Obstacles", {"obstacles": True}),
  ("Go2-Chase-Terrain", {"terrain": True}),
):
  register_mjlab_task(
    task_id=task_id,
    env_cfg=mid80_chase_env_cfg(**kw),
    play_env_cfg=mid80_chase_env_cfg(play=True, **kw),
    rl_cfg=RslRlOnPolicyRunnerCfg(),  # unused: training is SuperMimic (scripts/train.py)
  )

register_mjlab_task(
  task_id=VELOCITY_TASK,
  env_cfg=mid80_velocity_env_cfg(),
  play_env_cfg=mid80_velocity_env_cfg(play=True),
  rl_cfg=RslRlOnPolicyRunnerCfg(),
)

register_mjlab_task(
  task_id="MID80-Velocity-Terrain",
  env_cfg=mid80_velocity_terrain_env_cfg(),
  play_env_cfg=mid80_velocity_terrain_env_cfg(play=True),
  rl_cfg=RslRlOnPolicyRunnerCfg(),
)
