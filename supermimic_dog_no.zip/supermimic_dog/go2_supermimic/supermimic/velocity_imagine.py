"""SuperMimic rollouts for blind MID80 velocity tracking on flat ground or terrain.

The command is a desired forward/lateral speed in the robot yaw frame and a
yaw rate. It stays constant during the short imagined horizon; the real
environment resamples it every few seconds. No chase or dodge targets enter
the policy, rewards or critic for this task.
"""

from __future__ import annotations

from dataclasses import dataclass

import torch

from go2_supermimic.locomotion import MIN_BASE_HEIGHT, velocity_tracking_terms
from go2_supermimic.supermimic import state as st
from go2_supermimic.supermimic.imagine import ImagineCfg, Imagination, joint_torques
from go2_supermimic.target import terrain as tr


@dataclass
class VelocityRewardWeights:
  track_lin_vel_xy: float = 3.0
  track_ang_vel_z: float = 1.5
  upright: float = 1.0
  lin_vel_z_l2: float = -1.0
  tilt_rate_l2: float = -0.05
  joint_deviation_l2: float = -0.1
  base_height_low: float = -10.0
  action_rate_l2: float = -0.05
  dof_pos_limits: float = -1.0
  joint_torques_l2: float = -2e-5
  joint_acc_l2: float = -2.5e-7
  terminated: float = -200.0


class VelocityImagination(Imagination):
  """Use the existing model fitting, BPTT, soft survival and TD(lambda) learner."""

  def __init__(self, cfg: ImagineCfg, consts: st.RobotConsts, history: int,
               device: str, terms=st.VELOCITY_OBS_TERMS,
               field: tr.HeightField | None = None):
    self.cfg = cfg
    self.c = consts
    self.h = history
    self.device = device
    self.terms = terms
    self.field = field
    if tuple(terms) != st.VELOCITY_OBS_TERMS:
      raise ValueError("Blind velocity policies require proprioceptive observations without height_scan")
    self.use_scan = False
    self.use_obst = False
    self.critic_dim = st.STATE_DIM + 3 + st.CONTEXT_DIM
    self._step_fn = torch.compile(self._step, dynamic=False) if cfg.compile else self._step

  def context_state(self, packed: torch.Tensor) -> dict[str, torch.Tensor]:
    return {"velocity_command": packed.clone()}

  def critic_input(self, s, pose, gst, xi):
    return torch.cat([s, gst["velocity_command"], xi], dim=-1)

  def relief(self, pose, gst, grad: bool) -> torch.Tensor:
    """No terrain samples enter the blind world model or its imagined rollout."""
    return pose.new_empty((pose.shape[0], 0))

  def _rewards(self, s0, s1, pose1, gst, a, a_prev, k):
    cfg = self.cfg
    q = s1[:, st.Q] + k["default_q"]
    limits = k["soft_limits"]
    tau = joint_torques(s1, a, k, self.c)
    terms = velocity_tracking_terms(s1[:, st.V_YAW], s1[:, st.W_B], gst["velocity_command"])
    terms.update({
      "upright": torch.exp(-s1[:, st.GRAV][:, :2].square().sum(-1) / 0.4**2),
      "tilt_rate_l2": s1[:, st.W_B][:, :2].square().sum(-1),
      "joint_deviation_l2": s1[:, st.Q].square().sum(-1),
      "base_height_low": (MIN_BASE_HEIGHT - s1[:, 0]).clamp(min=0.0),
      "action_rate_l2": (a - a_prev).square().sum(-1),
      "dof_pos_limits": ((limits[..., 0] - q).clamp(min=0)
                         + (q - limits[..., 1]).clamp(min=0)).sum(-1),
      "joint_torques_l2": tau.square().sum(-1),
      "joint_acc_l2": ((s1[:, st.QD] - s0[:, st.QD]) / cfg.dt).square().sum(-1),
    })
    return sum(getattr(cfg.weights, name) * value for name, value in terms.items()) * cfg.dt, terms

  def _step(self, s, pose, a_prev, hist, gst, xi, enc_bias, k, dt, actor, wm):
    crit_in = self.critic_input(s, pose, gst, xi)
    action = actor(hist)
    relief = self.relief(pose, gst, grad=self.cfg.sensor_grad)
    s_next, dpose = wm(s, action, a_prev, xi, relief)
    pose_next = st.apply_pose_delta(pose, dpose)
    reward, _ = self._rewards(s, s_next, pose_next, gst, action, a_prev, k)
    done = self.fall_prob(s_next)
    reward = reward + self.cfg.weights.terminated * done * self.cfg.dt
    frame = st.obs_frame(s_next, action, None, enc_bias, noise=True,
                         velocity_command=gst["velocity_command"])
    hist = st.push_history(hist, frame, self.h, self.terms)
    return s_next, pose_next, action, hist, gst, reward, done, crit_in
