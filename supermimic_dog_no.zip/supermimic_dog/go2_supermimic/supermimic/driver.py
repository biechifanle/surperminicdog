"""MID80 checkpoint policies used to collect world-model training data.

The former Go2 MoE-CTS driver is intentionally rejected: its twelve position
commands cannot control MID80's twelve leg positions and four wheel velocities.
"""

from __future__ import annotations

import math

import torch

from go2_supermimic.supermimic import state as st


def checkpoint_task_type(checkpoint: dict) -> str:
  """Read command semantics, including MID80 checkpoints saved before this field."""
  task_type = checkpoint.get("task_type")
  if task_type in ("chase", "velocity"):
    return task_type
  task = checkpoint.get("cfg", {}).get("task", "")
  if task.startswith(("MID80-Chase-", "Go2-Chase-")):
    return "chase"
  if task.startswith("MID80-Velocity-"):
    return "velocity"
  raise ValueError("Checkpoint has no recognized task type; expected a MID80 chase or velocity task.")


def validate_checkpoint_task(checkpoint: dict, task_type: str, obs_terms=None,
                             history: int | None = None, allow_prefix: bool = False) -> None:
  """Prevent similarly shaped policies from interpreting a different command."""
  saved_type = checkpoint_task_type(checkpoint)
  if saved_type != task_type:
    raise ValueError(f"Checkpoint task type {saved_type!r} cannot control {task_type!r}; "
                     "train or resume a checkpoint for the same task type.")
  if history is not None and checkpoint.get("history", history) != history:
    raise ValueError("Checkpoint observation history does not match the environment.")
  saved_terms = checkpoint.get("obs_terms")
  if task_type == "velocity" and obs_terms is not None and not any(
    name == "height_scan" for name, _ in obs_terms
  ):
    saved_dim = checkpoint.get("obs_dim")
    saved_mean = checkpoint.get("actor", {}).get("norm.mean")
    if saved_dim is None and saved_mean is not None:
      saved_dim = saved_mean.shape[0]
    scan_dim = (history or checkpoint.get("history", 5)) * (
      sum(dim for _, dim in st.VELOCITY_OBS_TERMS) + st.SCAN_POINTS
    )
    if saved_dim == scan_dim or any(name == "height_scan" for name, _ in (saved_terms or ())):
      raise ValueError(
        "This checkpoint uses height_scan observations (650 inputs with five frames). "
        "Blind MID80 velocity tasks use 265 inputs. Retrain without --resume, "
        "or initialize from a compatible blind/flat velocity checkpoint."
      )
  if saved_terms is not None and obs_terms is not None:
    saved_terms = tuple(tuple(term) for term in saved_terms)
    expected = tuple(obs_terms)
    compatible = expected[:len(saved_terms)] == saved_terms if allow_prefix else expected == saved_terms
    if not compatible:
      raise ValueError("Checkpoint observation terms do not match the environment.")


class MoeCtsDriver:
  """Compatibility guard for the former twelve-action Go2 driver."""

  def __init__(self, env, path: str):
    raise ValueError(
      "The Go2 MoE-CTS driver has 12 position actions and cannot control MID80's "
      "12 leg positions plus 4 wheel velocities. Use a MID80 ActorDriver checkpoint."
    )


class ActorDriver:
  """One of our own checkpoints driving the env, e.g. a flat-ground chase-and-dodge
  policy on terrain, so the world model sees its jumps and ducks there. Its
  observation must be a prefix of the env's (true when the task only appends
  terms, like the terrain height scan)."""

  def __init__(self, path: str, env_obs_dim: int, device, task_type: str = "chase",
               obs_terms=None, history: int | None = None):
    from go2_supermimic.supermimic.train import Actor

    ck = torch.load(path, map_location=device, weights_only=False)
    st.validate_checkpoint_robot(ck)
    validate_checkpoint_task(ck, task_type, obs_terms, history, allow_prefix=True)
    self.obs_dim = ck["obs_dim"]
    if self.obs_dim > env_obs_dim:
      raise ValueError(f"Expert observation dimension {self.obs_dim} exceeds env {env_obs_dim}")
    self.actor = Actor(self.obs_dim, tuple(ck["cfg"]["actor_hidden"]), st.NUM_JOINTS).to(device)
    self.actor.load_state_dict(ck["actor"])
    self.actor.eval()

  @torch.no_grad()
  def act(self, obs: torch.Tensor) -> torch.Tensor:
    return self.actor(obs[:, : self.obs_dim])


class ChaseSteer:
  """Velocity commands for the driver: head for the chase ball (or, without one,
  a random waypoint in the arena) at a per-env random top speed, turning toward
  it like Isaac Lab's heading command."""

  def __init__(self, num_envs: int, device, vmax: tuple[float, float], radius: float):
    self.dev, self.vmax, self.radius = device, vmax, radius
    self.speed = torch.zeros(num_envs, device=device)
    self.goal = torch.zeros(num_envs, 2, device=device)
    self.timer = torch.zeros(num_envs, device=device)

  def resample(self, mask: torch.Tensor, center: torch.Tensor) -> None:
    k = int(mask.sum())
    if k == 0:
      return
    lo, hi = self.vmax
    self.speed[mask] = lo + (hi - lo) * torch.rand(k, device=self.dev)
    r = self.radius * torch.rand(k, device=self.dev).sqrt()
    th = 2 * math.pi * torch.rand(k, device=self.dev)
    self.goal[mask] = center[mask] + torch.stack([r * th.cos(), r * th.sin()], -1)
    self.timer[mask] = 2.0 + 3.0 * torch.rand(k, device=self.dev)

  def __call__(self, dt: float, pos: torch.Tensor, yaw: torch.Tensor, center: torch.Tensor,
               ball: torch.Tensor, has_ball: torch.Tensor) -> torch.Tensor:
    self.timer -= dt
    self.resample((self.timer <= 0) | ((self.goal - pos).norm(dim=-1) < 0.4), center)
    to = torch.where(has_ball.unsqueeze(-1), ball, self.goal) - pos
    err = torch.atan2(to[:, 1], to[:, 0]) - yaw
    err = torch.atan2(err.sin(), err.cos())
    v = torch.minimum(self.speed, 1.5 * to.norm(dim=-1))
    return torch.stack([v * err.cos().clamp(min=0), torch.zeros_like(v),
                        (1.5 * err).clamp(-1.5, 1.5)], -1)
