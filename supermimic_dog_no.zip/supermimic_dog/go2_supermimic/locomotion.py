"""Shared velocity-task constants and differentiable reward equations."""

from __future__ import annotations

import torch

VELOCITY_TASK = "MID80-Velocity-Flat"
COMMAND_SCALE = (2.0, 2.0, 1.0)
TRACKING_STD = 0.5
MIN_BASE_HEIGHT = 0.28


def velocity_tracking_terms(
  v_yaw: torch.Tensor, w_b: torch.Tensor, command: torch.Tensor,
) -> dict[str, torch.Tensor]:
  """Track planar speed in the yaw frame and yaw rate in the body frame.

  ``command`` contains forward/lateral speeds in m/s and yaw rate in rad/s;
  observation scaling is deliberately kept outside the reward calculation.
  """
  return {
    "track_lin_vel_xy": torch.exp(
      -(v_yaw[..., :2] - command[..., :2]).square().sum(-1) / TRACKING_STD**2
    ),
    "track_ang_vel_z": torch.exp(
      -(w_b[..., 2] - command[..., 2]).square() / TRACKING_STD**2
    ),
    "lin_vel_z_l2": v_yaw[..., 2].square(),
  }
